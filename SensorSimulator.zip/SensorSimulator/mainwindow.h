#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include <QMainWindow>
#include "GPS/CRMCView.h"
#include "GPS/GLL.h"
#include "GPS/GGA.h"
#include "GPS/ZDA.h"
#include "Server/Server.h"
#include "Server/UDPServer.h"
#include <QtNetwork/QUdpSocket>
#include "Server/TCPServer.h"
#include "GPS/IBS.h"
#include "GPS/AIS.h"
#include "GPS/LOG.h"
#include "GPS/AWOS.h"
#include "GPS/MWV.h"
#include "GPS/XDR.h"
#include "GPS/ECHO.h"
#include "GPS/GYRO.h"
#include "Radar/TacticalScene.h"
#include <QGraphicsView>
#include <QUdpSocket>
#include <QTimer>
namespace Ui {
class MainWindow;
}
class MainWindow : public QMainWindow
{
    Q_OBJECT
public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    static QString calculateChecksum(const QString &answer);
    void m_MemoryCreation();
    void m_instance();

private slots:
    void on_GPS_PB_clicked();
    void on_LOG_PB_clicked();
    void on_RMC_PB_clicked();
    void on_GLL_PB_clicked();
    void on_GGA_PB_clicked();
    void on_ZDA_PB_clicked();
    void on_pushButton_5_clicked();
    void on_pushButton_6_clicked();
    void on_pushButton_8_clicked();
    void on_GPS_Frame_3_customContextMenuRequested(const QPoint &pos);
    void on_pushButton_9_clicked();
    void on_AIS_PB_clicked();
    void on_AWOS_PB_clicked();
    void on_MWV_PB_clicked();
    void on_XDR_PB_clicked();
    void on_pushButton_4_clicked();
    void on_pushButton_clicked();
    void sendRadarData();
    //void on_Confirm_clicked();

private:
    Ui::MainWindow *ui;
    CRMCView *objCRMCView;
    GLL *objGLL;
    GGA *objGGA;
    ZDA *objZDA;
    Server *objServer;
    UDPServer *objUDPServer;
    TCPServer *objTCPServer;
    IBS *objIBS;
    AIS *objAIS;
    LOG *objLOG;
    AWOS *objAWOS;
    MWV *objMWV;
    XDR *objXDR;
    ECHO *objECHO;
    GYRO *objGYRO;
    TacticalScene *scene;
    QUdpSocket *udpSocket;

    QString generateRMC();
    QString generateGGA();
    QString generateGLL();
    QString generateZDA();
};
#endif // MAINWINDOW_H
