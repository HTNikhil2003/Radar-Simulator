#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    ui->GPS_Frame->hide();
    ui->GPS_Frame_2->hide();
    ui->GPS_Frame_3->hide();
    ui->GPS_Frame_4->hide();

    m_MemoryCreation();
}
MainWindow::~MainWindow()
{
    delete ui;
}
QString MainWindow::calculateChecksum(const QString &answer)
{
    int checksum = 0;
    for (int i = 0; i < answer.length(); ++i) {
        checksum ^= answer.at(i).toLatin1();
    }
    return QString::number(checksum,16).toUpper().rightJustified(2,'0');
}
void MainWindow::m_MemoryCreation()
{
    objCRMCView = new CRMCView(this);
    objCRMCView->setGeometry(200,0,600,600);
    objCRMCView->hide();

    objGLL = new GLL(this);
    objGLL->setGeometry(200,0,600,600);
    objGLL->hide();

    objGGA = new GGA(this);
    objGGA-> setGeometry(200,0,600,600);
    objGGA->hide();

    objZDA = new ZDA(this);
    objZDA->setGeometry(200,0,600,600);
    objZDA->hide();

    objServer = new Server(this);
    objServer ->setGeometry(200,100,600,600);
    objServer->hide();

    objUDPServer = new UDPServer(this);
    objUDPServer -> setGeometry(200,0,600,600);
    objUDPServer->hide();

    objTCPServer = new TCPServer(this);

    objIBS = new IBS(this);
    objIBS -> setGeometry(200,0,600,600);
    objIBS->hide();

    objAIS = new AIS(this);
    objAIS ->setGeometry(200,0,600,600);
    objAIS->hide();

    objLOG = new LOG(this);
    objLOG->setGeometry(100,0,600,600);
    objLOG->hide();

    objMWV = new MWV(this);
    objMWV->setGeometry(200,0,600,600);
    objMWV->hide();

    objXDR = new XDR (this);
    objXDR->setGeometry(200,0,600,600);
    objXDR->hide();

    objECHO = new ECHO (this);
    objECHO->setGeometry(200,0,600,600);
    objECHO->hide();

    objGYRO = new GYRO (this);
    objGYRO->setGeometry(200,0,600,600);
    objGYRO->hide();

    udpSocket = new QUdpSocket(this);
    QTimer *timer = new QTimer(this);
    connect(timer, &QTimer::timeout, this, &MainWindow::sendRadarData);
    timer->start(1000); //every 1 sec

    connect(objCRMCView, &CRMCView::positionChanged,
            objGGA, &GGA::updatePosition);

    connect(objCRMCView, &CRMCView::positionChanged,
            objGLL, &GLL::updatePosition);

    connect(objCRMCView, &CRMCView::sigToSetOwnPosition,
            objIBS, &IBS::slotToSetOwnPosition);

    connect(objLOG,&LOG::sigToUpdateSpeed,
            objCRMCView, &CRMCView::slotToUpdateSpeed);

    connect(objGYRO,&GYRO::sigToUpdateCourse,
            objCRMCView, &CRMCView::slotToUpdateCourse);


}

void MainWindow::on_GPS_PB_clicked()
{
    ui->GPS_Frame->show();
    ui->GPS_Frame_2->hide();
    ui->GPS_Frame_3->hide();
    objLOG->hide();
    ui->GPS_Frame_4->hide();
    objMWV->hide();
    objXDR->hide();
    objECHO->hide();
    objGYRO->hide();
}

void MainWindow::on_LOG_PB_clicked()
{
    ui->GPS_Frame->hide();
    ui->GPS_Frame_2->hide();
    ui->GPS_Frame_3->hide();
    objLOG->show();
    objGLL->hide();
    objGGA->hide();
    objCRMCView->hide();
    objZDA->hide();
    objServer->hide();
    objUDPServer->hide();
    objIBS->hide();
    objAIS->hide();
    ui->GPS_Frame_4->hide();
    objMWV->hide();
    objXDR->hide();
    objECHO->hide();
    objGYRO->hide();
}

void MainWindow::on_RMC_PB_clicked()
{
    objGLL->hide();
    objGGA->hide();
    objCRMCView->show();
    objZDA->hide();
    objServer->hide();
    objUDPServer->hide();
    objIBS->hide();
    objAIS->hide();
    objLOG->hide();
    ui->GPS_Frame_4->hide();
    objMWV->hide();
    objXDR->hide();
    objECHO->hide();
    objGYRO->hide();
}

void MainWindow::on_GLL_PB_clicked()
{
    objCRMCView->hide();
    objGLL->show();
    objGGA->hide();
    objZDA->hide();
    objServer->hide();
    objUDPServer->hide();
    objIBS->hide();
    objAIS->hide();
    objLOG->hide();
    ui->GPS_Frame_4->hide();
    objMWV->hide();
    objXDR->hide();
    objECHO->hide();
    objGYRO->hide();
}

void MainWindow::on_GGA_PB_clicked()
{
    objGGA->show();
    objGLL->hide();
    objCRMCView->hide();
    objZDA->hide();
    objServer->hide();
    objUDPServer->hide();
    objIBS->hide();
    objAIS->hide();
    objLOG->hide();
    ui->GPS_Frame_4->hide();
    objMWV->hide();
    objXDR->hide();
    objECHO->hide();
    objGYRO->hide();
}

void MainWindow::on_ZDA_PB_clicked()
{
    objZDA->show();
    objGLL->hide();
    objCRMCView->hide();
    objGGA->hide();
    objIBS->hide();
    objAIS->hide();
    objLOG->hide();
    ui->GPS_Frame_4->hide();
    objMWV->hide();
    objXDR->hide();
    objECHO->hide();
    objGYRO->hide();
}

void MainWindow::on_pushButton_5_clicked()
{
    ui->GPS_Frame_2->show();
    ui->GPS_Frame->hide();
    ui->GPS_Frame_3->hide();
    objAIS->hide();
    objLOG->hide();
    ui->GPS_Frame_4->hide();
    objMWV->hide();
    objXDR->hide();
    objECHO->hide();
    objGYRO->hide();
}

void MainWindow::on_pushButton_6_clicked()
{
    objServer->show();
    objUDPServer->show();
    objGLL->hide();
    objGGA->hide();
    objZDA->hide();
    objCRMCView->hide();
    objIBS->hide();
    objAIS->hide();
    objLOG->hide();
    ui->GPS_Frame_4->hide();
    objMWV->hide();
    objXDR->hide();
    objECHO->hide();
    objGYRO->hide();
}

void MainWindow::on_pushButton_8_clicked()
{
    ui->GPS_Frame_3->show();
    ui->GPS_Frame_2->hide();
    ui->GPS_Frame->hide();
    objLOG->hide();
    objIBS->hide();
    ui->GPS_Frame_4->hide();
    objMWV->hide();
    objXDR->hide();
    objECHO->hide();

}
void MainWindow::on_GPS_Frame_3_customContextMenuRequested(const QPoint &pos)
{}

void MainWindow::on_pushButton_9_clicked()
{
    objIBS->show();
    objGLL->hide();
    objCRMCView->hide();
    objGGA->hide();
    objZDA->hide();
    objServer->hide();
    objUDPServer->hide();
    objAIS->hide();
    objLOG->hide();
    ui->GPS_Frame_4->hide();
    objMWV->hide();
    objXDR->hide();
    objECHO->hide();
    objGYRO->hide();
}
void MainWindow::on_AIS_PB_clicked()
{
    objAIS->show();
    objIBS->hide();
    objGLL->hide();
    objCRMCView->hide();
    objGGA->hide();
    objZDA->hide();
    objServer->hide();
    objUDPServer->hide();
    ui->GPS_Frame->hide();
    ui->GPS_Frame_2->hide();
    ui->GPS_Frame_3->hide();
    objIBS->hide();
    objLOG->hide();
    ui->GPS_Frame_4->hide();
    objMWV->hide();
    objXDR->hide();
    objECHO->hide();
    objGYRO->hide();
}

void MainWindow::on_AWOS_PB_clicked()
{
    ui->GPS_Frame_4->show();
    objAIS->hide();
    objIBS->hide();
    objGLL->hide();
    objCRMCView->hide();
    objGGA->hide();
    objZDA->hide();
    objServer->hide();
    objUDPServer->hide();
    ui->GPS_Frame->hide();
    ui->GPS_Frame_2->hide();
    ui->GPS_Frame_3->hide();
    objIBS->hide();
    objLOG->hide();
    objMWV->hide();
    objXDR->hide();
    objECHO->hide();
    objGYRO->hide();
}

void MainWindow::on_MWV_PB_clicked()
{
 objMWV->show();
 ui->GPS_Frame_4->hide();
 objAIS->hide();
 objIBS->hide();
 objGLL->hide();
 objCRMCView->hide();
 objGGA->hide();
 objZDA->hide();
 objServer->hide();
 objUDPServer->hide();
 ui->GPS_Frame->hide();
 ui->GPS_Frame_2->hide();
 ui->GPS_Frame_3->hide();
 objIBS->hide();
 objLOG->hide();
 ui->GPS_Frame_4->show();
 objXDR->hide();
 objECHO->hide();
 objGYRO->hide();
}

void MainWindow::on_XDR_PB_clicked()
{
    objXDR->show();
    objMWV->hide();
    ui->GPS_Frame_4->hide();
    objAIS->hide();
    objIBS->hide();
    objGLL->hide();
    objCRMCView->hide();
    objGGA->hide();
    objZDA->hide();
    objServer->hide();
    objUDPServer->hide();
    ui->GPS_Frame->hide();
    ui->GPS_Frame_2->hide();
    ui->GPS_Frame_3->hide();
    objIBS->hide();
    objLOG->hide();
    ui->GPS_Frame_4->show();
    objECHO->hide();
    objGYRO->hide();
}

void MainWindow::on_pushButton_4_clicked()
{
    objECHO->show();
    objXDR->hide();
    objMWV->hide();
    ui->GPS_Frame_4->hide();
    objAIS->hide();
    objIBS->hide();
    objGLL->hide();
    objCRMCView->hide();
    objGGA->hide();
    objZDA->hide();
    objServer->hide();
    objUDPServer->hide();
    ui->GPS_Frame->hide();
    ui->GPS_Frame_2->hide();
    ui->GPS_Frame_3->hide();
    objIBS->hide();
    objLOG->hide();
    ui->GPS_Frame_4->hide();
    objGYRO->hide();
}

void MainWindow::on_pushButton_clicked()
{
    objGYRO->show();
    objECHO->hide();
    objXDR->hide();
    objMWV->hide();
    ui->GPS_Frame_4->hide();
    objAIS->hide();
    objIBS->hide();
    objGLL->hide();
    objCRMCView->hide();
    objGGA->hide();
    objZDA->hide();
    objServer->hide();
    objUDPServer->hide();
    ui->GPS_Frame->hide();
    ui->GPS_Frame_2->hide();
    ui->GPS_Frame_3->hide();
    objIBS->hide();
    objLOG->hide();
    ui->GPS_Frame_4->hide();
}

void MainWindow::sendRadarData()
{
    double range = 3.5;
    double bearing = 45.0;

    QString nmea = QString("$RADAR,%1,%2*00\r\n").arg(range).arg(bearing);

    udpSocket->writeDatagram(nmea.toUtf8(),QHostAddress("127.0.0.1"),45454);
}











