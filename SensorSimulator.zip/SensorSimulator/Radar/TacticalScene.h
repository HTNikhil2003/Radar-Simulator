#ifndef TACTICALSCENE_H
#define TACTICALSCENE_H

#include <QGraphicsScene>
#include <QTimer>

class TacticalScene : public QGraphicsScene
{
    Q_OBJECT

public:
    explicit TacticalScene(QObject *parent = nullptr);

    void setTarget(double range, double bearing);

protected:
    void drawBackground(QPainter *painter, const QRectF &rect) override;

private slots:
    void updateSweep();

private:
    double sweepAngle;
    double targetRange;
    double targetBearing;

    QTimer *timer;
};

#endif
