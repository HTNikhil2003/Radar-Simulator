#include "TacticalScene.h"
#include <QPainter>
#include <QtMath>

TacticalScene::TacticalScene(QObject *parent)
    : QGraphicsScene(parent),
      sweepAngle(0),
      targetRange(3),
      targetBearing(90)
{
    timer = new QTimer(this);
    connect(timer, &QTimer::timeout, this, &TacticalScene::updateSweep);
    timer->start(50);
}

void TacticalScene::updateSweep()
{
    sweepAngle += 2;
    if (sweepAngle >= 360)
        sweepAngle = 0;

    update();
}

void TacticalScene::setTarget(double range, double bearing)
{
    targetRange = range;
    targetBearing = bearing;
    update();
}

void TacticalScene::drawBackground(QPainter *painter, const QRectF &rect)
{
    Q_UNUSED(rect);

    painter->setRenderHint(QPainter::Antialiasing);

    QPointF center(0, 0);

    // 🔵 Draw circles
    painter->setPen(QPen(Qt::green, 1));

    for (int i = 1; i <= 5; i++)
    {
        painter->drawEllipse(center, i * 50, i * 50);
    }

    // ➕ Cross lines
    painter->drawLine(-250, 0, 250, 0);
    painter->drawLine(0, -250, 0, 250);

    // 🟢 Sweep line
    painter->setPen(QPen(Qt::green, 2));

    double rad = qDegreesToRadians(sweepAngle);
    QPointF sweepPoint(250 * cos(rad), -250 * sin(rad));

    painter->drawLine(center, sweepPoint);

    // ✈ Target
    double r = targetRange * 50;
    double angleRad = qDegreesToRadians(targetBearing);

    QPointF target(
        r * cos(angleRad),
        -r * sin(angleRad));

    painter->setBrush(Qt::green);
    painter->drawEllipse(target, 5, 5);
}
