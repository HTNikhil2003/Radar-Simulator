#ifndef RADAR_H
#define RADAR_H

#include <QMainWindow>
#include "TacticalScene.h"
#include <QFrame>

namespace Ui {
class RADAR;
}

class RADAR : public QFrame
{
    Q_OBJECT

public:
    explicit RADAR(QWidget *parent = nullptr);
    ~RADAR();

    void updateTarget(double range, double bearing);  // 🔗 connection

private:
    Ui::RADAR *ui;
    TacticalScene *scene;
};

#endif
