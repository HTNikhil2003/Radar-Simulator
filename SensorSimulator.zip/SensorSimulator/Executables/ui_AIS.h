/********************************************************************************
** Form generated from reading UI file 'AIS.ui'
**
** Created by: Qt User Interface Compiler version 5.12.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_AIS_H
#define UI_AIS_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QSpinBox>

QT_BEGIN_NAMESPACE

class Ui_AIS
{
public:
    QGroupBox *groupBox;
    QLabel *label;
    QSpinBox *Message_SB;
    QLabel *label_2;
    QLabel *label_3;
    QSpinBox *Number_SB;
    QLabel *label_4;
    QLabel *label_5;
    QSpinBox *Identifier_SB;
    QLabel *label_6;
    QLabel *label_7;
    QLabel *label_8;
    QSpinBox *Bits_SB;
    QLabel *label_9;
    QPushButton *Confirm_AIS;
    QPushButton *Cancel_AIS;
    QGroupBox *groupBox_2;
    QRadioButton *radioButton;
    QRadioButton *radioButton_2;
    QComboBox *comboBox;
    QPushButton *pushButton;
    QPushButton *pushButton_2;

    void setupUi(QFrame *AIS)
    {
        if (AIS->objectName().isEmpty())
            AIS->setObjectName(QString::fromUtf8("AIS"));
        AIS->resize(600, 600);
        AIS->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);"));
        groupBox = new QGroupBox(AIS);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setGeometry(QRect(30, 10, 471, 411));
        groupBox->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);"));
        label = new QLabel(groupBox);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(10, 50, 191, 31));
        Message_SB = new QSpinBox(groupBox);
        Message_SB->setObjectName(QString::fromUtf8("Message_SB"));
        Message_SB->setGeometry(QRect(220, 50, 91, 29));
        Message_SB->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        Message_SB->setMinimum(0);
        Message_SB->setMaximum(9);
        label_2 = new QLabel(groupBox);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(10, 100, 141, 20));
        label_3 = new QLabel(groupBox);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(320, 49, 63, 31));
        Number_SB = new QSpinBox(groupBox);
        Number_SB->setObjectName(QString::fromUtf8("Number_SB"));
        Number_SB->setGeometry(QRect(220, 90, 91, 31));
        Number_SB->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        Number_SB->setMaximum(9);
        label_4 = new QLabel(groupBox);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(320, 90, 63, 31));
        label_5 = new QLabel(groupBox);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(10, 140, 201, 20));
        Identifier_SB = new QSpinBox(groupBox);
        Identifier_SB->setObjectName(QString::fromUtf8("Identifier_SB"));
        Identifier_SB->setGeometry(QRect(220, 130, 91, 31));
        Identifier_SB->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        Identifier_SB->setMaximum(9);
        label_6 = new QLabel(groupBox);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(320, 130, 63, 31));
        label_7 = new QLabel(groupBox);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(10, 190, 91, 20));
        label_8 = new QLabel(groupBox);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setGeometry(QRect(10, 259, 111, 31));
        Bits_SB = new QSpinBox(groupBox);
        Bits_SB->setObjectName(QString::fromUtf8("Bits_SB"));
        Bits_SB->setGeometry(QRect(130, 260, 91, 31));
        Bits_SB->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        Bits_SB->setMaximum(5);
        label_9 = new QLabel(groupBox);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setGeometry(QRect(230, 260, 63, 31));
        Confirm_AIS = new QPushButton(groupBox);
        Confirm_AIS->setObjectName(QString::fromUtf8("Confirm_AIS"));
        Confirm_AIS->setGeometry(QRect(130, 330, 84, 28));
        Confirm_AIS->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        Cancel_AIS = new QPushButton(groupBox);
        Cancel_AIS->setObjectName(QString::fromUtf8("Cancel_AIS"));
        Cancel_AIS->setGeometry(QRect(220, 330, 84, 28));
        Cancel_AIS->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        groupBox_2 = new QGroupBox(groupBox);
        groupBox_2->setObjectName(QString::fromUtf8("groupBox_2"));
        groupBox_2->setGeometry(QRect(120, 160, 111, 51));
        radioButton = new QRadioButton(groupBox_2);
        radioButton->setObjectName(QString::fromUtf8("radioButton"));
        radioButton->setGeometry(QRect(40, 30, 20, 21));
        radioButton_2 = new QRadioButton(groupBox_2);
        radioButton_2->setObjectName(QString::fromUtf8("radioButton_2"));
        radioButton_2->setGeometry(QRect(40, 30, 21, 21));
        comboBox = new QComboBox(groupBox_2);
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->setObjectName(QString::fromUtf8("comboBox"));
        comboBox->setGeometry(QRect(0, 20, 111, 31));
        comboBox->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        pushButton = new QPushButton(groupBox);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(130, 360, 84, 28));
        pushButton->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        pushButton_2 = new QPushButton(groupBox);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(220, 360, 84, 28));
        pushButton_2->setStyleSheet(QString::fromUtf8("background-color: rgb(239, 41, 41);"));

        retranslateUi(AIS);

        QMetaObject::connectSlotsByName(AIS);
    } // setupUi

    void retranslateUi(QFrame *AIS)
    {
        AIS->setWindowTitle(QApplication::translate("AIS", "Frame", nullptr));
        groupBox->setTitle(QApplication::translate("AIS", "AIS", nullptr));
        label->setText(QApplication::translate("AIS", "<html><head/><body><p><span style=\" color:#8ae234;\">Sentences transfer Message:</span></p></body></html>", nullptr));
        label_2->setText(QApplication::translate("AIS", "<html><head/><body><p><span style=\" color:#8ae234;\">Sentence Number:</span></p></body></html>", nullptr));
        label_3->setText(QApplication::translate("AIS", "<html><head/><body><p><span style=\" color:#8ae234;\">(1 - 9)</span></p></body></html>", nullptr));
        label_4->setText(QApplication::translate("AIS", "<html><head/><body><p><span style=\" color:#8ae234;\">(1 - 9)</span></p></body></html>", nullptr));
        label_5->setText(QApplication::translate("AIS", "<html><head/><body><p><span style=\" color:#8ae234;\">Sequential message identifier:</span></p></body></html>", nullptr));
        label_6->setText(QApplication::translate("AIS", "<html><head/><body><p><span style=\" color:#8ae234;\">(1 - 9)</span></p></body></html>", nullptr));
        label_7->setText(QApplication::translate("AIS", "<html><head/><body><p><span style=\" color:#8ae234;\">AIS Channel:</span></p></body></html>", nullptr));
        label_8->setText(QApplication::translate("AIS", "<html><head/><body><p><span style=\" color:#8ae234;\">No. of Fill-Bits :</span></p></body></html>", nullptr));
        label_9->setText(QApplication::translate("AIS", "<html><head/><body><p><span style=\" color:#8ae234;\">(0-5)</span></p></body></html>", nullptr));
        Confirm_AIS->setText(QApplication::translate("AIS", "Confirm", nullptr));
        Cancel_AIS->setText(QApplication::translate("AIS", "Cancel", nullptr));
        groupBox_2->setTitle(QString());
        radioButton->setText(QApplication::translate("AIS", "A", nullptr));
        radioButton_2->setText(QApplication::translate("AIS", "B", nullptr));
        comboBox->setItemText(0, QApplication::translate("AIS", "A", nullptr));
        comboBox->setItemText(1, QApplication::translate("AIS", "B", nullptr));

        pushButton->setText(QApplication::translate("AIS", "ON", nullptr));
        pushButton_2->setText(QApplication::translate("AIS", "OFF", nullptr));
    } // retranslateUi

};

namespace Ui {
    class AIS: public Ui_AIS {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_AIS_H
