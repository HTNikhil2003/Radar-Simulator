/********************************************************************************
** Form generated from reading UI file 'GYRO.ui'
**
** Created by: Qt User Interface Compiler version 5.12.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GYRO_H
#define UI_GYRO_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>

QT_BEGIN_NAMESPACE

class Ui_GYRO
{
public:
    QGroupBox *groupBox;
    QDoubleSpinBox *doubleSpinBox;
    QLabel *label_2;
    QLabel *label;
    QRadioButton *radioButton;
    QRadioButton *radioButton_2;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;

    void setupUi(QFrame *GYRO)
    {
        if (GYRO->objectName().isEmpty())
            GYRO->setObjectName(QString::fromUtf8("GYRO"));
        GYRO->resize(600, 600);
        GYRO->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);"));
        groupBox = new QGroupBox(GYRO);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setGeometry(QRect(40, 60, 501, 221));
        groupBox->setStyleSheet(QString::fromUtf8("background-color: rgb(136, 138, 133);\n"
"background-color: rgb(46, 52, 54);"));
        doubleSpinBox = new QDoubleSpinBox(groupBox);
        doubleSpinBox->setObjectName(QString::fromUtf8("doubleSpinBox"));
        doubleSpinBox->setGeometry(QRect(200, 50, 111, 29));
        doubleSpinBox->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        doubleSpinBox->setMaximum(360.000000000000000);
        label_2 = new QLabel(groupBox);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(320, 50, 91, 31));
        label = new QLabel(groupBox);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(60, 50, 141, 31));
        radioButton = new QRadioButton(groupBox);
        radioButton->setObjectName(QString::fromUtf8("radioButton"));
        radioButton->setGeometry(QRect(200, 100, 61, 26));
        radioButton_2 = new QRadioButton(groupBox);
        radioButton_2->setObjectName(QString::fromUtf8("radioButton_2"));
        radioButton_2->setGeometry(QRect(270, 100, 106, 26));
        pushButton = new QPushButton(groupBox);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(160, 140, 84, 28));
        pushButton->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        pushButton_2 = new QPushButton(groupBox);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(250, 140, 84, 28));
        pushButton_2->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        pushButton_3 = new QPushButton(groupBox);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setGeometry(QRect(160, 180, 84, 28));
        pushButton_3->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        pushButton_4 = new QPushButton(groupBox);
        pushButton_4->setObjectName(QString::fromUtf8("pushButton_4"));
        pushButton_4->setGeometry(QRect(250, 180, 84, 28));
        pushButton_4->setStyleSheet(QString::fromUtf8("background-color: rgb(239, 41, 41);"));

        retranslateUi(GYRO);

        QMetaObject::connectSlotsByName(GYRO);
    } // setupUi

    void retranslateUi(QFrame *GYRO)
    {
        GYRO->setWindowTitle(QApplication::translate("GYRO", "Frame", nullptr));
        groupBox->setTitle(QString());
        label_2->setText(QApplication::translate("GYRO", "<html><head/><body><p><span style=\" color:#8ae234;\">Degree (360)</span></p></body></html>", nullptr));
        label->setText(QApplication::translate("GYRO", "<html><head/><body><p><span style=\" color:#8ae234;\">Heading in Degrees:</span></p></body></html>", nullptr));
        radioButton->setText(QApplication::translate("GYRO", "T", nullptr));
        radioButton_2->setText(QApplication::translate("GYRO", "F", nullptr));
        pushButton->setText(QApplication::translate("GYRO", "Confirm", nullptr));
        pushButton_2->setText(QApplication::translate("GYRO", "Cancel", nullptr));
        pushButton_3->setText(QApplication::translate("GYRO", "ON", nullptr));
        pushButton_4->setText(QApplication::translate("GYRO", "OFF", nullptr));
    } // retranslateUi

};

namespace Ui {
    class GYRO: public Ui_GYRO {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GYRO_H
