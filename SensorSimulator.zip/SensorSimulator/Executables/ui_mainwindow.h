/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.12.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QFrame *frame;
    QPushButton *GPS_PB;
    QPushButton *LOG_PB;
    QPushButton *AWOS_PB;
    QPushButton *pushButton_4;
    QPushButton *pushButton_5;
    QPushButton *pushButton_8;
    QPushButton *AIS_PB;
    QPushButton *pushButton;
    QFrame *GPS_Frame;
    QPushButton *RMC_PB;
    QPushButton *ZDA_PB;
    QPushButton *GLL_PB;
    QPushButton *GGA_PB;
    QFrame *GPS_Frame_2;
    QPushButton *pushButton_6;
    QFrame *GPS_Frame_3;
    QPushButton *pushButton_9;
    QFrame *GPS_Frame_4;
    QPushButton *MWV_PB;
    QPushButton *XDR_PB;
    QFrame *GPS_Frame_5;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(800, 600);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        frame = new QFrame(centralWidget);
        frame->setObjectName(QString::fromUtf8("frame"));
        frame->setGeometry(QRect(0, 0, 101, 600));
        frame->setStyleSheet(QString::fromUtf8("background-color: rgb(136, 138, 133);\n"
"background-color: rgb(0, 0, 0);"));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Raised);
        GPS_PB = new QPushButton(frame);
        GPS_PB->setObjectName(QString::fromUtf8("GPS_PB"));
        GPS_PB->setGeometry(QRect(20, 10, 60, 31));
        GPS_PB->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        LOG_PB = new QPushButton(frame);
        LOG_PB->setObjectName(QString::fromUtf8("LOG_PB"));
        LOG_PB->setGeometry(QRect(20, 60, 60, 31));
        LOG_PB->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        AWOS_PB = new QPushButton(frame);
        AWOS_PB->setObjectName(QString::fromUtf8("AWOS_PB"));
        AWOS_PB->setGeometry(QRect(20, 110, 60, 31));
        AWOS_PB->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        pushButton_4 = new QPushButton(frame);
        pushButton_4->setObjectName(QString::fromUtf8("pushButton_4"));
        pushButton_4->setGeometry(QRect(20, 160, 60, 31));
        pushButton_4->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        pushButton_5 = new QPushButton(frame);
        pushButton_5->setObjectName(QString::fromUtf8("pushButton_5"));
        pushButton_5->setGeometry(QRect(20, 520, 60, 40));
        pushButton_5->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        pushButton_8 = new QPushButton(frame);
        pushButton_8->setObjectName(QString::fromUtf8("pushButton_8"));
        pushButton_8->setGeometry(QRect(20, 210, 60, 31));
        pushButton_8->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        AIS_PB = new QPushButton(frame);
        AIS_PB->setObjectName(QString::fromUtf8("AIS_PB"));
        AIS_PB->setGeometry(QRect(20, 260, 60, 31));
        AIS_PB->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        pushButton = new QPushButton(frame);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(23, 310, 61, 31));
        pushButton->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        GPS_Frame = new QFrame(centralWidget);
        GPS_Frame->setObjectName(QString::fromUtf8("GPS_Frame"));
        GPS_Frame->setGeometry(QRect(100, 0, 101, 601));
        GPS_Frame->setStyleSheet(QString::fromUtf8("background-color: rgb(136, 138, 133);\n"
"background-color: rgb(0, 0, 0);"));
        GPS_Frame->setFrameShape(QFrame::StyledPanel);
        GPS_Frame->setFrameShadow(QFrame::Raised);
        RMC_PB = new QPushButton(GPS_Frame);
        RMC_PB->setObjectName(QString::fromUtf8("RMC_PB"));
        RMC_PB->setGeometry(QRect(20, 10, 61, 41));
        RMC_PB->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        ZDA_PB = new QPushButton(GPS_Frame);
        ZDA_PB->setObjectName(QString::fromUtf8("ZDA_PB"));
        ZDA_PB->setGeometry(QRect(20, 160, 61, 41));
        ZDA_PB->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        GLL_PB = new QPushButton(GPS_Frame);
        GLL_PB->setObjectName(QString::fromUtf8("GLL_PB"));
        GLL_PB->setGeometry(QRect(20, 110, 61, 41));
        GLL_PB->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        GGA_PB = new QPushButton(GPS_Frame);
        GGA_PB->setObjectName(QString::fromUtf8("GGA_PB"));
        GGA_PB->setGeometry(QRect(20, 60, 61, 41));
        GGA_PB->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        GPS_Frame_2 = new QFrame(centralWidget);
        GPS_Frame_2->setObjectName(QString::fromUtf8("GPS_Frame_2"));
        GPS_Frame_2->setGeometry(QRect(100, 0, 101, 601));
        GPS_Frame_2->setStyleSheet(QString::fromUtf8("background-color: rgb(136, 138, 133);\n"
"background-color: rgb(0, 0, 0);"));
        GPS_Frame_2->setFrameShape(QFrame::StyledPanel);
        GPS_Frame_2->setFrameShadow(QFrame::Raised);
        pushButton_6 = new QPushButton(GPS_Frame_2);
        pushButton_6->setObjectName(QString::fromUtf8("pushButton_6"));
        pushButton_6->setGeometry(QRect(20, 60, 60, 40));
        pushButton_6->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        GPS_Frame_3 = new QFrame(centralWidget);
        GPS_Frame_3->setObjectName(QString::fromUtf8("GPS_Frame_3"));
        GPS_Frame_3->setGeometry(QRect(100, 0, 101, 601));
        GPS_Frame_3->setStyleSheet(QString::fromUtf8("background-color: rgb(136, 138, 133);\n"
"background-color: rgb(0, 0, 0);"));
        GPS_Frame_3->setFrameShape(QFrame::StyledPanel);
        GPS_Frame_3->setFrameShadow(QFrame::Raised);
        pushButton_9 = new QPushButton(GPS_Frame_3);
        pushButton_9->setObjectName(QString::fromUtf8("pushButton_9"));
        pushButton_9->setGeometry(QRect(20, 60, 60, 40));
        pushButton_9->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        GPS_Frame_4 = new QFrame(centralWidget);
        GPS_Frame_4->setObjectName(QString::fromUtf8("GPS_Frame_4"));
        GPS_Frame_4->setGeometry(QRect(100, 0, 101, 601));
        GPS_Frame_4->setStyleSheet(QString::fromUtf8("background-color: rgb(136, 138, 133);\n"
"background-color: rgb(0, 0, 0);"));
        GPS_Frame_4->setFrameShape(QFrame::StyledPanel);
        GPS_Frame_4->setFrameShadow(QFrame::Raised);
        MWV_PB = new QPushButton(GPS_Frame_4);
        MWV_PB->setObjectName(QString::fromUtf8("MWV_PB"));
        MWV_PB->setGeometry(QRect(20, 60, 60, 40));
        MWV_PB->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        XDR_PB = new QPushButton(GPS_Frame_4);
        XDR_PB->setObjectName(QString::fromUtf8("XDR_PB"));
        XDR_PB->setGeometry(QRect(20, 120, 60, 40));
        XDR_PB->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        GPS_Frame_5 = new QFrame(centralWidget);
        GPS_Frame_5->setObjectName(QString::fromUtf8("GPS_Frame_5"));
        GPS_Frame_5->setGeometry(QRect(200, 0, 611, 601));
        GPS_Frame_5->setStyleSheet(QString::fromUtf8("background-color: rgb(136, 138, 133);\n"
"background-color: rgb(0, 0, 0);"));
        GPS_Frame_5->setFrameShape(QFrame::StyledPanel);
        GPS_Frame_5->setFrameShadow(QFrame::Raised);
        MainWindow->setCentralWidget(centralWidget);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", nullptr));
        GPS_PB->setText(QApplication::translate("MainWindow", "GPS", nullptr));
        LOG_PB->setText(QApplication::translate("MainWindow", "LOG", nullptr));
        AWOS_PB->setText(QApplication::translate("MainWindow", "AWOS", nullptr));
        pushButton_4->setText(QApplication::translate("MainWindow", "ECHO", nullptr));
        pushButton_5->setText(QApplication::translate("MainWindow", "SERVER", nullptr));
        pushButton_8->setText(QApplication::translate("MainWindow", "IBS", nullptr));
        AIS_PB->setText(QApplication::translate("MainWindow", "AIS", nullptr));
        pushButton->setText(QApplication::translate("MainWindow", "GYRO", nullptr));
        RMC_PB->setText(QApplication::translate("MainWindow", "RMC", nullptr));
        ZDA_PB->setText(QApplication::translate("MainWindow", "ZDA", nullptr));
        GLL_PB->setText(QApplication::translate("MainWindow", "GLL", nullptr));
        GGA_PB->setText(QApplication::translate("MainWindow", "GGA", nullptr));
        pushButton_6->setText(QApplication::translate("MainWindow", "UDP", nullptr));
        pushButton_9->setText(QApplication::translate("MainWindow", "TTM", nullptr));
        MWV_PB->setText(QApplication::translate("MainWindow", "MWV", nullptr));
        XDR_PB->setText(QApplication::translate("MainWindow", "XDR", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
