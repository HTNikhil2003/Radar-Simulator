/********************************************************************************
** Form generated from reading UI file 'CRMCView.ui'
**
** Created by: Qt User Interface Compiler version 5.12.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CRMCVIEW_H
#define UI_CRMCVIEW_H

#include <QtCore/QDate>
#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDateEdit>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_CRMCView
{
public:
    QGroupBox *groupBox;
    QLabel *label_3;
    QLabel *label_7;
    QLabel *label_5;
    QDoubleSpinBox *doubleSpinBox_3;
    QDoubleSpinBox *doubleSpinBox_4;
    QLabel *label_2;
    QLabel *label_4;
    QLabel *label_8;
    QLabel *label_9;
    QLabel *label_6;
    QTextEdit *textEdit;
    QTextEdit *textEdit_2;
    QSpinBox *spinBox;
    QSpinBox *spinBox_2;
    QComboBox *comboBox;
    QComboBox *comboBox_2;
    QLabel *label_25;
    QGroupBox *groupBox_2;
    QLabel *label_22;
    QLabel *label_19;
    QLabel *label_15;
    QLabel *label_21;
    QLabel *label_16;
    QLabel *label_13;
    QLabel *label_20;
    QDoubleSpinBox *doubleSpinBox_11;
    QLabel *label_12;
    QLabel *label_17;
    QLabel *label_14;
    QDateEdit *dateEdit;
    QLabel *label_18;
    QSpinBox *spinBox_4;
    QSpinBox *spinBox_3;
    QSpinBox *spinBox_5;
    QSpinBox *spinBox_6;
    QSpinBox *spinBox_7;
    QSpinBox *spinBox_8;
    QLabel *label;
    QGroupBox *groupBox_3;
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout;
    QRadioButton *radioButton_2;
    QRadioButton *radioButton;
    QComboBox *comboBox_4;
    QRadioButton *radioButton_3;
    QLabel *label_23;
    QGroupBox *groupBox_4;
    QWidget *layoutWidget1;
    QHBoxLayout *horizontalLayout_2;
    QRadioButton *radioButton_4;
    QComboBox *comboBox_3;
    QLabel *label_24;
    QWidget *layoutWidget2;
    QHBoxLayout *horizontalLayout_3;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QWidget *layoutWidget3;
    QHBoxLayout *horizontalLayout_4;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;

    void setupUi(QFrame *CRMCView)
    {
        if (CRMCView->objectName().isEmpty())
            CRMCView->setObjectName(QString::fromUtf8("CRMCView"));
        CRMCView->setEnabled(true);
        CRMCView->resize(600, 636);
        CRMCView->setSizeIncrement(QSize(10, 10));
        CRMCView->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);"));
        groupBox = new QGroupBox(CRMCView);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setGeometry(QRect(30, 0, 541, 161));
        groupBox->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);\n"
""));
        groupBox->setFlat(false);
        label_3 = new QLabel(groupBox);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(70, 110, 71, 21));
        label_7 = new QLabel(groupBox);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(260, 100, 111, 20));
        label_5 = new QLabel(groupBox);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(160, 100, 91, 20));
        doubleSpinBox_3 = new QDoubleSpinBox(groupBox);
        doubleSpinBox_3->setObjectName(QString::fromUtf8("doubleSpinBox_3"));
        doubleSpinBox_3->setGeometry(QRect(260, 60, 101, 29));
        doubleSpinBox_3->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        doubleSpinBox_3->setAlignment(Qt::AlignCenter);
        doubleSpinBox_3->setMaximum(59.590000000000003);
        doubleSpinBox_4 = new QDoubleSpinBox(groupBox);
        doubleSpinBox_4->setObjectName(QString::fromUtf8("doubleSpinBox_4"));
        doubleSpinBox_4->setGeometry(QRect(260, 120, 101, 29));
        doubleSpinBox_4->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        doubleSpinBox_4->setAlignment(Qt::AlignCenter);
        doubleSpinBox_4->setMaximum(59.590000000000003);
        label_2 = new QLabel(groupBox);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(80, 60, 63, 20));
        label_4 = new QLabel(groupBox);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(160, 40, 81, 20));
        label_8 = new QLabel(groupBox);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setGeometry(QRect(400, 40, 63, 20));
        label_9 = new QLabel(groupBox);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setGeometry(QRect(400, 100, 63, 20));
        label_6 = new QLabel(groupBox);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(260, 40, 111, 20));
        textEdit = new QTextEdit(groupBox);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));
        textEdit->setGeometry(QRect(450, 70, 16, 16));
        textEdit->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        textEdit_2 = new QTextEdit(groupBox);
        textEdit_2->setObjectName(QString::fromUtf8("textEdit_2"));
        textEdit_2->setGeometry(QRect(440, 120, 21, 21));
        textEdit_2->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        spinBox = new QSpinBox(groupBox);
        spinBox->setObjectName(QString::fromUtf8("spinBox"));
        spinBox->setGeometry(QRect(160, 60, 71, 29));
        spinBox->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        spinBox->setAlignment(Qt::AlignCenter);
        spinBox->setMaximum(90);
        spinBox_2 = new QSpinBox(groupBox);
        spinBox_2->setObjectName(QString::fromUtf8("spinBox_2"));
        spinBox_2->setGeometry(QRect(160, 120, 71, 29));
        spinBox_2->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        spinBox_2->setAlignment(Qt::AlignCenter);
        spinBox_2->setMaximum(90);
        comboBox = new QComboBox(groupBox);
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->setObjectName(QString::fromUtf8("comboBox"));
        comboBox->setGeometry(QRect(390, 60, 79, 28));
        comboBox->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        comboBox_2 = new QComboBox(groupBox);
        comboBox_2->addItem(QString());
        comboBox_2->addItem(QString());
        comboBox_2->setObjectName(QString::fromUtf8("comboBox_2"));
        comboBox_2->setGeometry(QRect(390, 120, 79, 28));
        comboBox_2->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        label_25 = new QLabel(groupBox);
        label_25->setObjectName(QString::fromUtf8("label_25"));
        label_25->setGeometry(QRect(0, 0, 161, 21));
        groupBox_2 = new QGroupBox(CRMCView);
        groupBox_2->setObjectName(QString::fromUtf8("groupBox_2"));
        groupBox_2->setGeometry(QRect(30, 170, 541, 211));
        groupBox_2->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);\n"
""));
        label_22 = new QLabel(groupBox_2);
        label_22->setObjectName(QString::fromUtf8("label_22"));
        label_22->setGeometry(QRect(560, 70, 63, 20));
        label_19 = new QLabel(groupBox_2);
        label_19->setObjectName(QString::fromUtf8("label_19"));
        label_19->setGeometry(QRect(340, 120, 91, 20));
        label_15 = new QLabel(groupBox_2);
        label_15->setObjectName(QString::fromUtf8("label_15"));
        label_15->setGeometry(QRect(100, 150, 141, 20));
        label_21 = new QLabel(groupBox_2);
        label_21->setObjectName(QString::fromUtf8("label_21"));
        label_21->setGeometry(QRect(340, 180, 81, 20));
        label_16 = new QLabel(groupBox_2);
        label_16->setObjectName(QString::fromUtf8("label_16"));
        label_16->setGeometry(QRect(110, 180, 131, 20));
        label_13 = new QLabel(groupBox_2);
        label_13->setObjectName(QString::fromUtf8("label_13"));
        label_13->setGeometry(QRect(80, 80, 161, 20));
        label_20 = new QLabel(groupBox_2);
        label_20->setObjectName(QString::fromUtf8("label_20"));
        label_20->setGeometry(QRect(340, 150, 91, 20));
        doubleSpinBox_11 = new QDoubleSpinBox(groupBox_2);
        doubleSpinBox_11->setObjectName(QString::fromUtf8("doubleSpinBox_11"));
        doubleSpinBox_11->setGeometry(QRect(560, 90, 81, 29));
        label_12 = new QLabel(groupBox_2);
        label_12->setObjectName(QString::fromUtf8("label_12"));
        label_12->setGeometry(QRect(150, 29, 91, 31));
        label_17 = new QLabel(groupBox_2);
        label_17->setObjectName(QString::fromUtf8("label_17"));
        label_17->setGeometry(QRect(350, 60, 81, 20));
        label_14 = new QLabel(groupBox_2);
        label_14->setObjectName(QString::fromUtf8("label_14"));
        label_14->setGeometry(QRect(110, 120, 131, 20));
        dateEdit = new QDateEdit(groupBox_2);
        dateEdit->setObjectName(QString::fromUtf8("dateEdit"));
        dateEdit->setGeometry(QRect(260, 30, 121, 29));
        dateEdit->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        dateEdit->setDate(QDate(2026, 4, 27));
        label_18 = new QLabel(groupBox_2);
        label_18->setObjectName(QString::fromUtf8("label_18"));
        label_18->setGeometry(QRect(260, 60, 71, 20));
        spinBox_4 = new QSpinBox(groupBox_2);
        spinBox_4->setObjectName(QString::fromUtf8("spinBox_4"));
        spinBox_4->setGeometry(QRect(350, 80, 71, 29));
        spinBox_4->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        spinBox_4->setMaximum(59);
        spinBox_3 = new QSpinBox(groupBox_2);
        spinBox_3->setObjectName(QString::fromUtf8("spinBox_3"));
        spinBox_3->setGeometry(QRect(260, 80, 71, 29));
        spinBox_3->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        spinBox_3->setAlignment(Qt::AlignCenter);
        spinBox_3->setMaximum(23);
        spinBox_3->setSingleStep(1);
        spinBox_3->setStepType(QAbstractSpinBox::DefaultStepType);
        spinBox_3->setValue(0);
        spinBox_5 = new QSpinBox(groupBox_2);
        spinBox_5->setObjectName(QString::fromUtf8("spinBox_5"));
        spinBox_5->setGeometry(QRect(260, 120, 71, 29));
        spinBox_5->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        spinBox_5->setAlignment(Qt::AlignCenter);
        spinBox_5->setMaximum(60);
        spinBox_6 = new QSpinBox(groupBox_2);
        spinBox_6->setObjectName(QString::fromUtf8("spinBox_6"));
        spinBox_6->setGeometry(QRect(260, 150, 71, 29));
        spinBox_6->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        spinBox_6->setAlignment(Qt::AlignCenter);
        spinBox_6->setMaximum(360);
        spinBox_7 = new QSpinBox(groupBox_2);
        spinBox_7->setObjectName(QString::fromUtf8("spinBox_7"));
        spinBox_7->setGeometry(QRect(260, 180, 71, 29));
        spinBox_7->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        spinBox_7->setAlignment(Qt::AlignCenter);
        spinBox_7->setMaximum(30);
        spinBox_8 = new QSpinBox(groupBox_2);
        spinBox_8->setObjectName(QString::fromUtf8("spinBox_8"));
        spinBox_8->setGeometry(QRect(440, 80, 71, 29));
        spinBox_8->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        spinBox_8->setMaximum(59);
        label = new QLabel(groupBox_2);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(440, 60, 63, 20));
        groupBox_3 = new QGroupBox(CRMCView);
        groupBox_3->setObjectName(QString::fromUtf8("groupBox_3"));
        groupBox_3->setGeometry(QRect(29, 390, 541, 61));
        groupBox_3->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);\n"
""));
        layoutWidget = new QWidget(groupBox_3);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(250, 40, 81, 21));
        horizontalLayout = new QHBoxLayout(layoutWidget);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        radioButton_2 = new QRadioButton(groupBox_3);
        radioButton_2->setObjectName(QString::fromUtf8("radioButton_2"));
        radioButton_2->setGeometry(QRect(250, 40, 41, 26));
        radioButton = new QRadioButton(groupBox_3);
        radioButton->setObjectName(QString::fromUtf8("radioButton"));
        radioButton->setGeometry(QRect(250, 40, 101, 20));
        comboBox_4 = new QComboBox(groupBox_3);
        comboBox_4->addItem(QString());
        comboBox_4->addItem(QString());
        comboBox_4->setObjectName(QString::fromUtf8("comboBox_4"));
        comboBox_4->setGeometry(QRect(240, 30, 111, 31));
        comboBox_4->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        radioButton_3 = new QRadioButton(groupBox_3);
        radioButton_3->setObjectName(QString::fromUtf8("radioButton_3"));
        radioButton_3->setGeometry(QRect(350, 110, 21, 20));
        label_23 = new QLabel(groupBox_3);
        label_23->setObjectName(QString::fromUtf8("label_23"));
        label_23->setGeometry(QRect(0, 0, 161, 21));
        groupBox_4 = new QGroupBox(CRMCView);
        groupBox_4->setObjectName(QString::fromUtf8("groupBox_4"));
        groupBox_4->setGeometry(QRect(29, 460, 541, 61));
        groupBox_4->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);\n"
""));
        layoutWidget1 = new QWidget(groupBox_4);
        layoutWidget1->setObjectName(QString::fromUtf8("layoutWidget1"));
        layoutWidget1->setGeometry(QRect(260, 30, 91, 30));
        horizontalLayout_2 = new QHBoxLayout(layoutWidget1);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        radioButton_4 = new QRadioButton(groupBox_4);
        radioButton_4->setObjectName(QString::fromUtf8("radioButton_4"));
        radioButton_4->setGeometry(QRect(291, 30, 20, 26));
        comboBox_3 = new QComboBox(groupBox_4);
        comboBox_3->addItem(QString());
        comboBox_3->addItem(QString());
        comboBox_3->setObjectName(QString::fromUtf8("comboBox_3"));
        comboBox_3->setGeometry(QRect(240, 30, 111, 31));
        comboBox_3->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        label_24 = new QLabel(groupBox_4);
        label_24->setObjectName(QString::fromUtf8("label_24"));
        label_24->setGeometry(QRect(0, 0, 161, 21));
        layoutWidget2 = new QWidget(CRMCView);
        layoutWidget2->setObjectName(QString::fromUtf8("layoutWidget2"));
        layoutWidget2->setGeometry(QRect(160, 530, 281, 51));
        horizontalLayout_3 = new QHBoxLayout(layoutWidget2);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalLayout_3->setContentsMargins(0, 0, 0, 0);
        pushButton = new QPushButton(layoutWidget2);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));

        horizontalLayout_3->addWidget(pushButton);

        pushButton_2 = new QPushButton(layoutWidget2);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));

        horizontalLayout_3->addWidget(pushButton_2);

        layoutWidget3 = new QWidget(CRMCView);
        layoutWidget3->setObjectName(QString::fromUtf8("layoutWidget3"));
        layoutWidget3->setGeometry(QRect(220, 570, 172, 31));
        horizontalLayout_4 = new QHBoxLayout(layoutWidget3);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        horizontalLayout_4->setContentsMargins(0, 0, 0, 0);
        pushButton_3 = new QPushButton(layoutWidget3);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));

        horizontalLayout_4->addWidget(pushButton_3);

        pushButton_4 = new QPushButton(layoutWidget3);
        pushButton_4->setObjectName(QString::fromUtf8("pushButton_4"));
        pushButton_4->setStyleSheet(QString::fromUtf8("background-color: rgb(239, 41, 41);"));

        horizontalLayout_4->addWidget(pushButton_4);


        retranslateUi(CRMCView);

        QMetaObject::connectSlotsByName(CRMCView);
    } // setupUi

    void retranslateUi(QFrame *CRMCView)
    {
        CRMCView->setWindowTitle(QApplication::translate("CRMCView", "Frame", nullptr));
        groupBox->setTitle(QApplication::translate("CRMCView", "Position:", nullptr));
        label_3->setText(QApplication::translate("CRMCView", "<html><head/><body><p><span style=\" color:#8ae234;\">Longitude</span></p></body></html>", nullptr));
        label_7->setText(QApplication::translate("CRMCView", "<html><head/><body><p><span style=\" color:#8ae234;\">MM.MM(59.59)</span></p></body></html>", nullptr));
        label_5->setText(QApplication::translate("CRMCView", "<html><head/><body><p><span style=\" color:#8ae234;\">  DD(0-90)</span></p></body></html>", nullptr));
        label_2->setText(QApplication::translate("CRMCView", "<html><head/><body><p><span style=\" color:#8ae234;\">Latitude</span></p></body></html>", nullptr));
        label_4->setText(QApplication::translate("CRMCView", "<html><head/><body><p><span style=\" color:#8ae234;\">  DD(0-90)</span></p></body></html>", nullptr));
        label_8->setText(QApplication::translate("CRMCView", "<html><head/><body><p><span style=\" color:#8ae234;\"> Dir(N/S)</span></p></body></html>", nullptr));
        label_9->setText(QApplication::translate("CRMCView", "<html><head/><body><p><span style=\" color:#8ae234;\"> Dir(E/W)</span></p></body></html>", nullptr));
        label_6->setText(QApplication::translate("CRMCView", "<html><head/><body><p><span style=\" color:#8ae234;\">MM.MM(59.59)</span></p></body></html>", nullptr));
        comboBox->setItemText(0, QApplication::translate("CRMCView", "N", nullptr));
        comboBox->setItemText(1, QApplication::translate("CRMCView", "S", nullptr));

        comboBox_2->setItemText(0, QApplication::translate("CRMCView", "E", nullptr));
        comboBox_2->setItemText(1, QApplication::translate("CRMCView", "W", nullptr));

        label_25->setText(QApplication::translate("CRMCView", "<html><head/><body><p><span style=\" color:#8ae234;\">Position:</span></p></body></html>", nullptr));
        groupBox_2->setTitle(QString());
        label_22->setText(QApplication::translate("CRMCView", "SS(0-59)", nullptr));
        label_19->setText(QApplication::translate("CRMCView", "<html><head/><body><p><span style=\" color:#8ae234;\">Knots(0-60)</span></p></body></html>", nullptr));
        label_15->setText(QApplication::translate("CRMCView", "<html><head/><body><p><span style=\" color:#8ae234;\">Course Over Ground:</span></p></body></html>", nullptr));
        label_21->setText(QApplication::translate("CRMCView", "<html><head/><body><p><span style=\" color:#8ae234;\">Deg (0-30)</span></p></body></html>", nullptr));
        label_16->setText(QApplication::translate("CRMCView", "<html><head/><body><p><span style=\" color:#8ae234;\">Magnetic Variation:</span></p></body></html>", nullptr));
        label_13->setText(QApplication::translate("CRMCView", "<html><head/><body><p><span style=\" color:#8ae234;\">Observation Time(UTC):</span></p></body></html>", nullptr));
        label_20->setText(QApplication::translate("CRMCView", "<html><head/><body><p><span style=\" color:#8ae234;\">Deg (0-360)</span></p></body></html>", nullptr));
        label_12->setText(QApplication::translate("CRMCView", "<html><head/><body><p><span style=\" color:#8ae234;\">Present Date:</span></p></body></html>", nullptr));
        label_17->setText(QApplication::translate("CRMCView", "<html><head/><body><p><span style=\" color:#8ae234;\">MM(0-59)</span></p></body></html>", nullptr));
        label_14->setText(QApplication::translate("CRMCView", "<html><head/><body><p><span style=\" color:#8ae234;\">Speed Over Ground:</span></p></body></html>", nullptr));
        label_18->setText(QApplication::translate("CRMCView", "<html><head/><body><p><span style=\" color:#8ae234;\">HH(0-23)</span></p></body></html>", nullptr));
        label->setText(QApplication::translate("CRMCView", "<html><head/><body><p><span style=\" color:#8ae234;\">SS(0-59)</span></p></body></html>", nullptr));
        groupBox_3->setTitle(QApplication::translate("CRMCView", "Position Valid:", nullptr));
        radioButton_2->setText(QApplication::translate("CRMCView", "Invalid", nullptr));
        radioButton->setText(QApplication::translate("CRMCView", "Valid", nullptr));
        comboBox_4->setItemText(0, QApplication::translate("CRMCView", "A", nullptr));
        comboBox_4->setItemText(1, QApplication::translate("CRMCView", "V", nullptr));

        radioButton_3->setText(QApplication::translate("CRMCView", "East", nullptr));
        label_23->setText(QApplication::translate("CRMCView", "<html><head/><body><p><span style=\" color:#8ae234;\">Position Valid:</span></p></body></html>", nullptr));
        groupBox_4->setTitle(QApplication::translate("CRMCView", "Magnetic Variation Dir:", nullptr));
        radioButton_4->setText(QApplication::translate("CRMCView", "West", nullptr));
        comboBox_3->setItemText(0, QApplication::translate("CRMCView", "E", nullptr));
        comboBox_3->setItemText(1, QApplication::translate("CRMCView", "W", nullptr));

        label_24->setText(QApplication::translate("CRMCView", "<html><head/><body><p><span style=\" color:#8ae234;\">Magnetic Variation Dir:</span></p></body></html>", nullptr));
        pushButton->setText(QApplication::translate("CRMCView", "Confirm", nullptr));
        pushButton_2->setText(QApplication::translate("CRMCView", "Cancel", nullptr));
        pushButton_3->setText(QApplication::translate("CRMCView", "ON", nullptr));
        pushButton_4->setText(QApplication::translate("CRMCView", "OFF", nullptr));
    } // retranslateUi

};

namespace Ui {
    class CRMCView: public Ui_CRMCView {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CRMCVIEW_H
