/****************************************************************************
** Meta object code from reading C++ file 'CRMCView.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../GPS/CRMCView.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'CRMCView.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_CRMCView_t {
    QByteArrayData data[20];
    char stringdata0[317];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_CRMCView_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_CRMCView_t qt_meta_stringdata_CRMCView = {
    {
QT_MOC_LITERAL(0, 0, 8), // "CRMCView"
QT_MOC_LITERAL(1, 9, 15), // "positionChanged"
QT_MOC_LITERAL(2, 25, 0), // ""
QT_MOC_LITERAL(3, 26, 5), // "latDD"
QT_MOC_LITERAL(4, 32, 5), // "latMM"
QT_MOC_LITERAL(5, 38, 5), // "lonDD"
QT_MOC_LITERAL(6, 44, 5), // "lonMM"
QT_MOC_LITERAL(7, 50, 19), // "sigToSetOwnPosition"
QT_MOC_LITERAL(8, 70, 17), // "slotToUpdateSpeed"
QT_MOC_LITERAL(9, 88, 5), // "speed"
QT_MOC_LITERAL(10, 94, 18), // "slotToUpdateCourse"
QT_MOC_LITERAL(11, 113, 22), // "on_radioButton_clicked"
QT_MOC_LITERAL(12, 136, 24), // "on_radioButton_2_clicked"
QT_MOC_LITERAL(13, 161, 24), // "on_radioButton_3_clicked"
QT_MOC_LITERAL(14, 186, 24), // "on_radioButton_4_clicked"
QT_MOC_LITERAL(15, 211, 21), // "on_pushButton_clicked"
QT_MOC_LITERAL(16, 233, 23), // "on_pushButton_2_clicked"
QT_MOC_LITERAL(17, 257, 11), // "updateGPRMC"
QT_MOC_LITERAL(18, 269, 23), // "on_pushButton_3_clicked"
QT_MOC_LITERAL(19, 293, 23) // "on_pushButton_4_clicked"

    },
    "CRMCView\0positionChanged\0\0latDD\0latMM\0"
    "lonDD\0lonMM\0sigToSetOwnPosition\0"
    "slotToUpdateSpeed\0speed\0slotToUpdateCourse\0"
    "on_radioButton_clicked\0on_radioButton_2_clicked\0"
    "on_radioButton_3_clicked\0"
    "on_radioButton_4_clicked\0on_pushButton_clicked\0"
    "on_pushButton_2_clicked\0updateGPRMC\0"
    "on_pushButton_3_clicked\0on_pushButton_4_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_CRMCView[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      13,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    4,   79,    2, 0x06 /* Public */,
       7,    2,   88,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       8,    1,   93,    2, 0x0a /* Public */,
      10,    1,   96,    2, 0x0a /* Public */,
      11,    0,   99,    2, 0x08 /* Private */,
      12,    0,  100,    2, 0x08 /* Private */,
      13,    0,  101,    2, 0x08 /* Private */,
      14,    0,  102,    2, 0x08 /* Private */,
      15,    0,  103,    2, 0x08 /* Private */,
      16,    0,  104,    2, 0x08 /* Private */,
      17,    0,  105,    2, 0x08 /* Private */,
      18,    0,  106,    2, 0x08 /* Private */,
      19,    0,  107,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void, QMetaType::Int, QMetaType::Double, QMetaType::Int, QMetaType::Double,    3,    4,    5,    6,
    QMetaType::Void, QMetaType::Double, QMetaType::Double,    2,    2,

 // slots: parameters
    QMetaType::Void, QMetaType::Double,    9,
    QMetaType::Void, QMetaType::Double,    9,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void CRMCView::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        CRMCView *_t = static_cast<CRMCView *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->positionChanged((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3])),(*reinterpret_cast< double(*)>(_a[4]))); break;
        case 1: _t->sigToSetOwnPosition((*reinterpret_cast< double(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2]))); break;
        case 2: _t->slotToUpdateSpeed((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 3: _t->slotToUpdateCourse((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 4: _t->on_radioButton_clicked(); break;
        case 5: _t->on_radioButton_2_clicked(); break;
        case 6: _t->on_radioButton_3_clicked(); break;
        case 7: _t->on_radioButton_4_clicked(); break;
        case 8: _t->on_pushButton_clicked(); break;
        case 9: _t->on_pushButton_2_clicked(); break;
        case 10: _t->updateGPRMC(); break;
        case 11: _t->on_pushButton_3_clicked(); break;
        case 12: _t->on_pushButton_4_clicked(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (CRMCView::*)(int , double , int , double );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CRMCView::positionChanged)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (CRMCView::*)(double , double );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CRMCView::sigToSetOwnPosition)) {
                *result = 1;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject CRMCView::staticMetaObject = { {
    &QFrame::staticMetaObject,
    qt_meta_stringdata_CRMCView.data,
    qt_meta_data_CRMCView,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *CRMCView::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *CRMCView::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CRMCView.stringdata0))
        return static_cast<void*>(this);
    return QFrame::qt_metacast(_clname);
}

int CRMCView::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QFrame::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 13)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 13;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 13)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 13;
    }
    return _id;
}

// SIGNAL 0
void CRMCView::positionChanged(int _t1, double _t2, int _t3, double _t4)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)), const_cast<void*>(reinterpret_cast<const void*>(&_t4)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void CRMCView::sigToSetOwnPosition(double _t1, double _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
