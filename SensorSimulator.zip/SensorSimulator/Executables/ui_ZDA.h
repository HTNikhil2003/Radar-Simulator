/********************************************************************************
** Form generated from reading UI file 'ZDA.ui'
**
** Created by: Qt User Interface Compiler version 5.12.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ZDA_H
#define UI_ZDA_H

#include <QtCore/QDate>
#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDateEdit>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpinBox>

QT_BEGIN_NAMESPACE

class Ui_ZDA
{
public:
    QGroupBox *groupBox;
    QSpinBox *spinBox;
    QLabel *label_17;
    QSpinBox *spinBox_2;
    QLabel *label_16;
    QSpinBox *spinBox_3;
    QLabel *label_15;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_18;
    QLabel *label_19;
    QSpinBox *spinBox_4;
    QSpinBox *spinBox_5;
    QLabel *label_3;
    QDateEdit *dateEdit;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;

    void setupUi(QFrame *ZDA)
    {
        if (ZDA->objectName().isEmpty())
            ZDA->setObjectName(QString::fromUtf8("ZDA"));
        ZDA->resize(600, 600);
        ZDA->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);"));
        groupBox = new QGroupBox(ZDA);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setGeometry(QRect(0, 0, 601, 401));
        groupBox->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);"));
        spinBox = new QSpinBox(groupBox);
        spinBox->setObjectName(QString::fromUtf8("spinBox"));
        spinBox->setGeometry(QRect(220, 90, 71, 29));
        spinBox->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        spinBox->setAlignment(Qt::AlignCenter);
        label_17 = new QLabel(groupBox);
        label_17->setObjectName(QString::fromUtf8("label_17"));
        label_17->setGeometry(QRect(440, 70, 63, 20));
        spinBox_2 = new QSpinBox(groupBox);
        spinBox_2->setObjectName(QString::fromUtf8("spinBox_2"));
        spinBox_2->setGeometry(QRect(330, 90, 71, 29));
        spinBox_2->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        spinBox_2->setAlignment(Qt::AlignCenter);
        label_16 = new QLabel(groupBox);
        label_16->setObjectName(QString::fromUtf8("label_16"));
        label_16->setGeometry(QRect(330, 70, 81, 20));
        spinBox_3 = new QSpinBox(groupBox);
        spinBox_3->setObjectName(QString::fromUtf8("spinBox_3"));
        spinBox_3->setGeometry(QRect(440, 90, 71, 29));
        spinBox_3->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        spinBox_3->setAlignment(Qt::AlignCenter);
        label_15 = new QLabel(groupBox);
        label_15->setObjectName(QString::fromUtf8("label_15"));
        label_15->setGeometry(QRect(220, 70, 63, 20));
        label = new QLabel(groupBox);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(40, 90, 121, 20));
        label_2 = new QLabel(groupBox);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(60, 170, 101, 20));
        label_18 = new QLabel(groupBox);
        label_18->setObjectName(QString::fromUtf8("label_18"));
        label_18->setGeometry(QRect(330, 150, 71, 20));
        label_19 = new QLabel(groupBox);
        label_19->setObjectName(QString::fromUtf8("label_19"));
        label_19->setGeometry(QRect(220, 150, 63, 20));
        spinBox_4 = new QSpinBox(groupBox);
        spinBox_4->setObjectName(QString::fromUtf8("spinBox_4"));
        spinBox_4->setGeometry(QRect(330, 170, 71, 29));
        spinBox_4->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        spinBox_4->setAlignment(Qt::AlignCenter);
        spinBox_4->setMaximum(59);
        spinBox_5 = new QSpinBox(groupBox);
        spinBox_5->setObjectName(QString::fromUtf8("spinBox_5"));
        spinBox_5->setGeometry(QRect(220, 170, 71, 29));
        spinBox_5->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        spinBox_5->setAlignment(Qt::AlignCenter);
        spinBox_5->setMaximum(13);
        label_3 = new QLabel(groupBox);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(70, 229, 91, 31));
        dateEdit = new QDateEdit(groupBox);
        dateEdit->setObjectName(QString::fromUtf8("dateEdit"));
        dateEdit->setGeometry(QRect(220, 230, 121, 29));
        dateEdit->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        dateEdit->setDateTime(QDateTime(QDate(2026, 4, 29), QTime(0, 0, 0)));
        dateEdit->setDate(QDate(2026, 4, 29));
        pushButton = new QPushButton(groupBox);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(210, 310, 84, 28));
        pushButton->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        pushButton_2 = new QPushButton(groupBox);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(310, 310, 84, 28));
        pushButton_2->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        pushButton_3 = new QPushButton(groupBox);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setGeometry(QRect(210, 350, 84, 28));
        pushButton_3->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        pushButton_4 = new QPushButton(groupBox);
        pushButton_4->setObjectName(QString::fromUtf8("pushButton_4"));
        pushButton_4->setGeometry(QRect(310, 350, 84, 28));
        pushButton_4->setStyleSheet(QString::fromUtf8("background-color: rgb(239, 41, 41);"));

        retranslateUi(ZDA);

        QMetaObject::connectSlotsByName(ZDA);
    } // setupUi

    void retranslateUi(QFrame *ZDA)
    {
        ZDA->setWindowTitle(QApplication::translate("ZDA", "Frame", nullptr));
        groupBox->setTitle(QString());
        label_17->setText(QApplication::translate("ZDA", "<html><head/><body><p><span style=\" color:#8ae234;\">SS(0-59)</span></p></body></html>", nullptr));
        label_16->setText(QApplication::translate("ZDA", "<html><head/><body><p><span style=\" color:#8ae234;\">MM(0-59)</span></p></body></html>", nullptr));
        label_15->setText(QApplication::translate("ZDA", "<html><head/><body><p><span style=\" color:#8ae234;\">HH(0-23)</span></p></body></html>", nullptr));
        label->setText(QApplication::translate("ZDA", "<html><head/><body><p><span style=\" color:#8ae234;\">Observation Team:</span></p></body></html>", nullptr));
        label_2->setText(QApplication::translate("ZDA", "<html><head/><body><p><span style=\" color:#8ae234;\">Local Zone set:</span></p></body></html>", nullptr));
        label_18->setText(QApplication::translate("ZDA", "<html><head/><body><p><span style=\" color:#8ae234;\">MM(0-59)</span></p></body></html>", nullptr));
        label_19->setText(QApplication::translate("ZDA", "<html><head/><body><p><span style=\" color:#8ae234;\">HH(0-13)</span></p></body></html>", nullptr));
        label_3->setText(QApplication::translate("ZDA", "<html><head/><body><p><span style=\" color:#8ae234;\">Present Date:</span></p></body></html>", nullptr));
        dateEdit->setDisplayFormat(QApplication::translate("ZDA", "dd.MM.yyyy", nullptr));
        pushButton->setText(QApplication::translate("ZDA", "Confirm", nullptr));
        pushButton_2->setText(QApplication::translate("ZDA", "Cancel", nullptr));
        pushButton_3->setText(QApplication::translate("ZDA", "ON", nullptr));
        pushButton_4->setText(QApplication::translate("ZDA", "OFF", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ZDA: public Ui_ZDA {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ZDA_H
