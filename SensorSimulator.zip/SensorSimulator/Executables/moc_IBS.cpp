/****************************************************************************
** Meta object code from reading C++ file 'IBS.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../GPS/IBS.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'IBS.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_IBS_t {
    QByteArrayData data[23];
    char stringdata0[429];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_IBS_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_IBS_t qt_meta_stringdata_IBS = {
    {
QT_MOC_LITERAL(0, 0, 3), // "IBS"
QT_MOC_LITERAL(1, 4, 20), // "slotToSetOwnPosition"
QT_MOC_LITERAL(2, 25, 0), // ""
QT_MOC_LITERAL(3, 26, 8), // "latitude"
QT_MOC_LITERAL(4, 35, 9), // "longitude"
QT_MOC_LITERAL(5, 45, 22), // "on_radioButton_clicked"
QT_MOC_LITERAL(6, 68, 21), // "on_pushButton_clicked"
QT_MOC_LITERAL(7, 90, 23), // "on_pushButton_2_clicked"
QT_MOC_LITERAL(8, 114, 23), // "on_pushButton_4_clicked"
QT_MOC_LITERAL(9, 138, 21), // "on_Confirm_PB_clicked"
QT_MOC_LITERAL(10, 160, 25), // "on_radioButton_14_clicked"
QT_MOC_LITERAL(11, 186, 25), // "on_radioButton_15_clicked"
QT_MOC_LITERAL(12, 212, 25), // "on_radioButton_16_clicked"
QT_MOC_LITERAL(13, 238, 25), // "on_radioButton_17_clicked"
QT_MOC_LITERAL(14, 264, 23), // "on_pushButton_6_clicked"
QT_MOC_LITERAL(15, 288, 23), // "on_pushButton_5_clicked"
QT_MOC_LITERAL(16, 312, 25), // "on_spinBox_9_valueChanged"
QT_MOC_LITERAL(17, 338, 4), // "arg1"
QT_MOC_LITERAL(18, 343, 14), // "updateTrackPos"
QT_MOC_LITERAL(19, 358, 26), // "on_spinBox_12_valueChanged"
QT_MOC_LITERAL(20, 385, 5), // "value"
QT_MOC_LITERAL(21, 391, 32), // "on_comboBox_4_currentTextChanged"
QT_MOC_LITERAL(22, 424, 4) // "unit"

    },
    "IBS\0slotToSetOwnPosition\0\0latitude\0"
    "longitude\0on_radioButton_clicked\0"
    "on_pushButton_clicked\0on_pushButton_2_clicked\0"
    "on_pushButton_4_clicked\0on_Confirm_PB_clicked\0"
    "on_radioButton_14_clicked\0"
    "on_radioButton_15_clicked\0"
    "on_radioButton_16_clicked\0"
    "on_radioButton_17_clicked\0"
    "on_pushButton_6_clicked\0on_pushButton_5_clicked\0"
    "on_spinBox_9_valueChanged\0arg1\0"
    "updateTrackPos\0on_spinBox_12_valueChanged\0"
    "value\0on_comboBox_4_currentTextChanged\0"
    "unit"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_IBS[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      16,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    2,   94,    2, 0x0a /* Public */,
       5,    0,   99,    2, 0x08 /* Private */,
       6,    0,  100,    2, 0x08 /* Private */,
       7,    0,  101,    2, 0x08 /* Private */,
       8,    0,  102,    2, 0x08 /* Private */,
       9,    0,  103,    2, 0x08 /* Private */,
      10,    0,  104,    2, 0x08 /* Private */,
      11,    0,  105,    2, 0x08 /* Private */,
      12,    0,  106,    2, 0x08 /* Private */,
      13,    0,  107,    2, 0x08 /* Private */,
      14,    0,  108,    2, 0x08 /* Private */,
      15,    0,  109,    2, 0x08 /* Private */,
      16,    1,  110,    2, 0x08 /* Private */,
      18,    0,  113,    2, 0x08 /* Private */,
      19,    1,  114,    2, 0x08 /* Private */,
      21,    1,  117,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void, QMetaType::Double, QMetaType::Double,    3,    4,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   17,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   20,
    QMetaType::Void, QMetaType::QString,   22,

       0        // eod
};

void IBS::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        IBS *_t = static_cast<IBS *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->slotToSetOwnPosition((*reinterpret_cast< double(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2]))); break;
        case 1: _t->on_radioButton_clicked(); break;
        case 2: _t->on_pushButton_clicked(); break;
        case 3: _t->on_pushButton_2_clicked(); break;
        case 4: _t->on_pushButton_4_clicked(); break;
        case 5: _t->on_Confirm_PB_clicked(); break;
        case 6: _t->on_radioButton_14_clicked(); break;
        case 7: _t->on_radioButton_15_clicked(); break;
        case 8: _t->on_radioButton_16_clicked(); break;
        case 9: _t->on_radioButton_17_clicked(); break;
        case 10: _t->on_pushButton_6_clicked(); break;
        case 11: _t->on_pushButton_5_clicked(); break;
        case 12: _t->on_spinBox_9_valueChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 13: _t->updateTrackPos(); break;
        case 14: _t->on_spinBox_12_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 15: _t->on_comboBox_4_currentTextChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject IBS::staticMetaObject = { {
    &QFrame::staticMetaObject,
    qt_meta_stringdata_IBS.data,
    qt_meta_data_IBS,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *IBS::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *IBS::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_IBS.stringdata0))
        return static_cast<void*>(this);
    return QFrame::qt_metacast(_clname);
}

int IBS::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QFrame::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 16)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 16;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 16)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 16;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
