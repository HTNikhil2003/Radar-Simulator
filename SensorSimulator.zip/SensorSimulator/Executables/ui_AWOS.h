/********************************************************************************
** Form generated from reading UI file 'AWOS.ui'
**
** Created by: Qt User Interface Compiler version 5.12.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_AWOS_H
#define UI_AWOS_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>

QT_BEGIN_NAMESPACE

class Ui_AWOS
{
public:

    void setupUi(QFrame *AWOS)
    {
        if (AWOS->objectName().isEmpty())
            AWOS->setObjectName(QString::fromUtf8("AWOS"));
        AWOS->resize(600, 600);

        retranslateUi(AWOS);

        QMetaObject::connectSlotsByName(AWOS);
    } // setupUi

    void retranslateUi(QFrame *AWOS)
    {
        AWOS->setWindowTitle(QApplication::translate("AWOS", "Frame", nullptr));
    } // retranslateUi

};

namespace Ui {
    class AWOS: public Ui_AWOS {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_AWOS_H
