/********************************************************************************
** Form generated from reading UI file 'GGA.ui'
**
** Created by: Qt User Interface Compiler version 5.12.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GGA_H
#define UI_GGA_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_GGA
{
public:
    QGroupBox *groupBox;
    QDoubleSpinBox *doubleSpinBox_4;
    QLabel *label_2;
    QDoubleSpinBox *doubleSpinBox_3;
    QLabel *label_9;
    QLabel *label_4;
    QLabel *label_5;
    QLabel *label_6;
    QLabel *label_8;
    QLabel *label_7;
    QLabel *label_3;
    QSpinBox *spinBox_10;
    QSpinBox *spinBox_11;
    QTextEdit *textEdit;
    QTextEdit *textEdit_2;
    QComboBox *comboBox_2;
    QComboBox *comboBox_3;
    QSpinBox *spinBox;
    QSpinBox *spinBox_2;
    QSpinBox *spinBox_3;
    QSpinBox *spinBox_4;
    QSpinBox *spinBox_5;
    QSpinBox *spinBox_6;
    QComboBox *comboBox;
    QSpinBox *spinBox_7;
    QSpinBox *spinBox_8;
    QSpinBox *spinBox_9;
    QLabel *label_19;
    QLabel *label_20;
    QLabel *label_21;
    QLabel *label_22;
    QLabel *label_23;
    QLabel *label_24;
    QLabel *label_25;
    QLabel *label_26;
    QLabel *label_27;
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QWidget *layoutWidget1;
    QVBoxLayout *verticalLayout;
    QLabel *label;
    QLabel *label_12;
    QLabel *label_13;
    QLabel *label_14;
    QLabel *label_15;
    QLabel *label_17;
    QLabel *label_16;
    QLabel *label_18;
    QWidget *layoutWidget2;
    QHBoxLayout *horizontalLayout_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;

    void setupUi(QFrame *GGA)
    {
        if (GGA->objectName().isEmpty())
            GGA->setObjectName(QString::fromUtf8("GGA"));
        GGA->setEnabled(true);
        GGA->resize(656, 603);
        GGA->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);"));
        groupBox = new QGroupBox(GGA);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setEnabled(true);
        groupBox->setGeometry(QRect(10, 0, 671, 161));
        groupBox->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);"));
        doubleSpinBox_4 = new QDoubleSpinBox(groupBox);
        doubleSpinBox_4->setObjectName(QString::fromUtf8("doubleSpinBox_4"));
        doubleSpinBox_4->setGeometry(QRect(330, 120, 101, 29));
        doubleSpinBox_4->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        doubleSpinBox_4->setAlignment(Qt::AlignCenter);
        doubleSpinBox_4->setMaximum(59.990000000000002);
        label_2 = new QLabel(groupBox);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(70, 60, 63, 20));
        doubleSpinBox_3 = new QDoubleSpinBox(groupBox);
        doubleSpinBox_3->setObjectName(QString::fromUtf8("doubleSpinBox_3"));
        doubleSpinBox_3->setGeometry(QRect(330, 60, 101, 29));
        doubleSpinBox_3->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        doubleSpinBox_3->setAlignment(Qt::AlignCenter);
        doubleSpinBox_3->setMaximum(59.990000000000002);
        label_9 = new QLabel(groupBox);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setGeometry(QRect(500, 100, 63, 20));
        label_4 = new QLabel(groupBox);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(170, 40, 63, 20));
        label_5 = new QLabel(groupBox);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(170, 100, 91, 20));
        label_6 = new QLabel(groupBox);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(330, 40, 111, 20));
        label_8 = new QLabel(groupBox);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setGeometry(QRect(500, 40, 63, 20));
        label_7 = new QLabel(groupBox);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(330, 100, 111, 20));
        label_3 = new QLabel(groupBox);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(60, 120, 71, 20));
        spinBox_10 = new QSpinBox(groupBox);
        spinBox_10->setObjectName(QString::fromUtf8("spinBox_10"));
        spinBox_10->setGeometry(QRect(160, 60, 91, 29));
        spinBox_10->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        spinBox_10->setAlignment(Qt::AlignCenter);
        spinBox_10->setMaximum(90);
        spinBox_11 = new QSpinBox(groupBox);
        spinBox_11->setObjectName(QString::fromUtf8("spinBox_11"));
        spinBox_11->setGeometry(QRect(160, 120, 91, 29));
        spinBox_11->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        spinBox_11->setAlignment(Qt::AlignCenter);
        spinBox_11->setMaximum(90);
        textEdit = new QTextEdit(groupBox);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));
        textEdit->setGeometry(QRect(520, 60, 21, 16));
        textEdit->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        textEdit_2 = new QTextEdit(groupBox);
        textEdit_2->setObjectName(QString::fromUtf8("textEdit_2"));
        textEdit_2->setGeometry(QRect(520, 130, 21, 16));
        textEdit_2->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        comboBox_2 = new QComboBox(groupBox);
        comboBox_2->addItem(QString());
        comboBox_2->addItem(QString());
        comboBox_2->setObjectName(QString::fromUtf8("comboBox_2"));
        comboBox_2->setGeometry(QRect(490, 60, 79, 28));
        comboBox_2->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        comboBox_3 = new QComboBox(groupBox);
        comboBox_3->addItem(QString());
        comboBox_3->addItem(QString());
        comboBox_3->setObjectName(QString::fromUtf8("comboBox_3"));
        comboBox_3->setGeometry(QRect(490, 120, 79, 28));
        comboBox_3->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        spinBox = new QSpinBox(GGA);
        spinBox->setObjectName(QString::fromUtf8("spinBox"));
        spinBox->setGeometry(QRect(340, 190, 71, 29));
        spinBox->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        spinBox->setAlignment(Qt::AlignCenter);
        spinBox->setMaximum(23);
        spinBox->setValue(0);
        spinBox_2 = new QSpinBox(GGA);
        spinBox_2->setObjectName(QString::fromUtf8("spinBox_2"));
        spinBox_2->setGeometry(QRect(430, 190, 71, 29));
        spinBox_2->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        spinBox_2->setAlignment(Qt::AlignCenter);
        spinBox_3 = new QSpinBox(GGA);
        spinBox_3->setObjectName(QString::fromUtf8("spinBox_3"));
        spinBox_3->setGeometry(QRect(520, 190, 71, 29));
        spinBox_3->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        spinBox_3->setAlignment(Qt::AlignCenter);
        spinBox_3->setMaximum(59);
        spinBox_4 = new QSpinBox(GGA);
        spinBox_4->setObjectName(QString::fromUtf8("spinBox_4"));
        spinBox_4->setGeometry(QRect(340, 230, 151, 29));
        spinBox_4->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        spinBox_4->setAlignment(Qt::AlignCenter);
        spinBox_4->setMaximum(1);
        spinBox_5 = new QSpinBox(GGA);
        spinBox_5->setObjectName(QString::fromUtf8("spinBox_5"));
        spinBox_5->setGeometry(QRect(340, 280, 151, 29));
        spinBox_5->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        spinBox_5->setAlignment(Qt::AlignCenter);
        spinBox_6 = new QSpinBox(GGA);
        spinBox_6->setObjectName(QString::fromUtf8("spinBox_6"));
        spinBox_6->setGeometry(QRect(340, 320, 151, 29));
        spinBox_6->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        spinBox_6->setAlignment(Qt::AlignCenter);
        comboBox = new QComboBox(GGA);
        comboBox->addItem(QString());
        comboBox->setObjectName(QString::fromUtf8("comboBox"));
        comboBox->setGeometry(QRect(340, 360, 151, 28));
        comboBox->setLayoutDirection(Qt::LeftToRight);
        comboBox->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        spinBox_7 = new QSpinBox(GGA);
        spinBox_7->setObjectName(QString::fromUtf8("spinBox_7"));
        spinBox_7->setGeometry(QRect(340, 400, 151, 29));
        spinBox_7->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        spinBox_7->setAlignment(Qt::AlignCenter);
        spinBox_7->setMaximum(1000);
        spinBox_8 = new QSpinBox(GGA);
        spinBox_8->setObjectName(QString::fromUtf8("spinBox_8"));
        spinBox_8->setGeometry(QRect(340, 440, 151, 29));
        spinBox_8->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        spinBox_8->setAlignment(Qt::AlignCenter);
        spinBox_8->setMaximum(12);
        spinBox_9 = new QSpinBox(GGA);
        spinBox_9->setObjectName(QString::fromUtf8("spinBox_9"));
        spinBox_9->setGeometry(QRect(340, 480, 151, 29));
        spinBox_9->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        spinBox_9->setAlignment(Qt::AlignCenter);
        spinBox_9->setMaximum(12);
        label_19 = new QLabel(GGA);
        label_19->setObjectName(QString::fromUtf8("label_19"));
        label_19->setGeometry(QRect(340, 170, 63, 20));
        label_20 = new QLabel(GGA);
        label_20->setObjectName(QString::fromUtf8("label_20"));
        label_20->setGeometry(QRect(430, 170, 71, 20));
        label_21 = new QLabel(GGA);
        label_21->setObjectName(QString::fromUtf8("label_21"));
        label_21->setGeometry(QRect(520, 170, 63, 20));
        label_22 = new QLabel(GGA);
        label_22->setObjectName(QString::fromUtf8("label_22"));
        label_22->setGeometry(QRect(500, 230, 63, 31));
        label_23 = new QLabel(GGA);
        label_23->setObjectName(QString::fromUtf8("label_23"));
        label_23->setGeometry(QRect(500, 280, 63, 31));
        label_24 = new QLabel(GGA);
        label_24->setObjectName(QString::fromUtf8("label_24"));
        label_24->setGeometry(QRect(500, 320, 91, 31));
        label_25 = new QLabel(GGA);
        label_25->setObjectName(QString::fromUtf8("label_25"));
        label_25->setGeometry(QRect(500, 400, 91, 31));
        label_26 = new QLabel(GGA);
        label_26->setObjectName(QString::fromUtf8("label_26"));
        label_26->setGeometry(QRect(500, 440, 63, 31));
        label_27 = new QLabel(GGA);
        label_27->setObjectName(QString::fromUtf8("label_27"));
        label_27->setGeometry(QRect(500, 480, 63, 31));
        layoutWidget = new QWidget(GGA);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(197, 530, 261, 30));
        horizontalLayout = new QHBoxLayout(layoutWidget);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        pushButton = new QPushButton(layoutWidget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));

        horizontalLayout->addWidget(pushButton);

        pushButton_2 = new QPushButton(layoutWidget);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));

        horizontalLayout->addWidget(pushButton_2);

        layoutWidget1 = new QWidget(GGA);
        layoutWidget1->setObjectName(QString::fromUtf8("layoutWidget1"));
        layoutWidget1->setGeometry(QRect(10, 193, 311, 321));
        verticalLayout = new QVBoxLayout(layoutWidget1);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(layoutWidget1);
        label->setObjectName(QString::fromUtf8("label"));
        label->setStyleSheet(QString::fromUtf8(""));

        verticalLayout->addWidget(label);

        label_12 = new QLabel(layoutWidget1);
        label_12->setObjectName(QString::fromUtf8("label_12"));

        verticalLayout->addWidget(label_12);

        label_13 = new QLabel(layoutWidget1);
        label_13->setObjectName(QString::fromUtf8("label_13"));

        verticalLayout->addWidget(label_13);

        label_14 = new QLabel(layoutWidget1);
        label_14->setObjectName(QString::fromUtf8("label_14"));

        verticalLayout->addWidget(label_14);

        label_15 = new QLabel(layoutWidget1);
        label_15->setObjectName(QString::fromUtf8("label_15"));

        verticalLayout->addWidget(label_15);

        label_17 = new QLabel(layoutWidget1);
        label_17->setObjectName(QString::fromUtf8("label_17"));

        verticalLayout->addWidget(label_17);

        label_16 = new QLabel(layoutWidget1);
        label_16->setObjectName(QString::fromUtf8("label_16"));
        label_16->setStyleSheet(QString::fromUtf8(""));

        verticalLayout->addWidget(label_16);

        label_18 = new QLabel(layoutWidget1);
        label_18->setObjectName(QString::fromUtf8("label_18"));

        verticalLayout->addWidget(label_18);

        layoutWidget2 = new QWidget(GGA);
        layoutWidget2->setObjectName(QString::fromUtf8("layoutWidget2"));
        layoutWidget2->setGeometry(QRect(280, 570, 172, 30));
        horizontalLayout_2 = new QHBoxLayout(layoutWidget2);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        pushButton_3 = new QPushButton(layoutWidget2);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));

        horizontalLayout_2->addWidget(pushButton_3);

        pushButton_4 = new QPushButton(layoutWidget2);
        pushButton_4->setObjectName(QString::fromUtf8("pushButton_4"));
        pushButton_4->setStyleSheet(QString::fromUtf8("background-color: rgb(239, 41, 41);"));

        horizontalLayout_2->addWidget(pushButton_4);


        retranslateUi(GGA);

        QMetaObject::connectSlotsByName(GGA);
    } // setupUi

    void retranslateUi(QFrame *GGA)
    {
        GGA->setWindowTitle(QApplication::translate("GGA", "Frame", nullptr));
        groupBox->setTitle(QApplication::translate("GGA", "Position", nullptr));
        label_2->setText(QApplication::translate("GGA", "<html><head/><body><p><span style=\" color:#8ae234;\">Latitude</span></p></body></html>", nullptr));
        label_9->setText(QApplication::translate("GGA", "<html><head/><body><p><span style=\" color:#8ae234;\"> Dir(E/W)</span></p></body></html>", nullptr));
        label_4->setText(QApplication::translate("GGA", "<html><head/><body><p><span style=\" color:#8ae234;\">DD(0-90)</span></p></body></html>", nullptr));
        label_5->setText(QApplication::translate("GGA", "<html><head/><body><p><span style=\" color:#8ae234;\">DD(0-90)</span></p></body></html>", nullptr));
        label_6->setText(QApplication::translate("GGA", "<html><head/><body><p><span style=\" color:#8ae234;\">MM.MM(59.59)</span></p></body></html>", nullptr));
        label_8->setText(QApplication::translate("GGA", "<html><head/><body><p><span style=\" color:#8ae234;\"> Dir(N/S)</span></p></body></html>", nullptr));
        label_7->setText(QApplication::translate("GGA", "<html><head/><body><p><span style=\" color:#8ae234;\">MM.MM(59.59)</span></p></body></html>", nullptr));
        label_3->setText(QApplication::translate("GGA", "<html><head/><body><p><span style=\" color:#8ae234;\">Longitude</span></p></body></html>", nullptr));
        comboBox_2->setItemText(0, QApplication::translate("GGA", "N", nullptr));
        comboBox_2->setItemText(1, QApplication::translate("GGA", "S", nullptr));

        comboBox_3->setItemText(0, QApplication::translate("GGA", "E", nullptr));
        comboBox_3->setItemText(1, QApplication::translate("GGA", "W", nullptr));

        comboBox->setItemText(0, QApplication::translate("GGA", "1", nullptr));

        label_19->setText(QApplication::translate("GGA", "<html><head/><body><p><span style=\" color:#8ae234;\">HH(0-23)</span></p></body></html>", nullptr));
        label_20->setText(QApplication::translate("GGA", "<html><head/><body><p><span style=\" color:#8ae234;\">MM(0-59)</span></p></body></html>", nullptr));
        label_21->setText(QApplication::translate("GGA", "<html><head/><body><p><span style=\" color:#8ae234;\">SS(0-59)</span></p></body></html>", nullptr));
        label_22->setText(QApplication::translate("GGA", "<html><head/><body><p><span style=\" color:#8ae234;\">(0-1)</span></p></body></html>", nullptr));
        label_23->setText(QApplication::translate("GGA", "<html><head/><body><p><span style=\" color:#8ae234;\">M(0-100)</span></p></body></html>", nullptr));
        label_24->setText(QApplication::translate("GGA", "<html><head/><body><p><span style=\" color:#8ae234;\">M(-100-100)</span></p></body></html>", nullptr));
        label_25->setText(QApplication::translate("GGA", "<html><head/><body><p><span style=\" color:#8ae234;\">Sec(0-1000)</span></p></body></html>", nullptr));
        label_26->setText(QApplication::translate("GGA", "<html><head/><body><p><span style=\" color:#8ae234;\">(0-12)</span></p></body></html>", nullptr));
        label_27->setText(QApplication::translate("GGA", "<html><head/><body><p><span style=\" color:#8ae234;\">(0-12)</span></p></body></html>", nullptr));
        pushButton->setText(QApplication::translate("GGA", "Confirm", nullptr));
        pushButton_2->setText(QApplication::translate("GGA", "Cancel", nullptr));
        label->setText(QApplication::translate("GGA", "<html><head/><body><p><span style=\" color:#8ae234;\">UTC Of Position</span></p></body></html>", nullptr));
        label_12->setText(QApplication::translate("GGA", "<html><head/><body><p><span style=\" color:#8ae234;\">Horizontal Dilution Of Precision</span></p></body></html>", nullptr));
        label_13->setText(QApplication::translate("GGA", "<html><head/><body><p><span style=\" color:#8ae234;\">Antenna Altitude Above/below Mean Sea Level</span></p></body></html>", nullptr));
        label_14->setText(QApplication::translate("GGA", "<html><head/><body><p><span style=\" color:#8ae234;\">Geoldal Seperation</span></p></body></html>", nullptr));
        label_15->setText(QApplication::translate("GGA", "<html><head/><body><p><span style=\" color:#8ae234;\">GPS Quality Indicator</span></p></body></html>", nullptr));
        label_17->setText(QApplication::translate("GGA", "<html><head/><body><p><span style=\" color:#8ae234;\">Number of Satellites</span></p></body></html>", nullptr));
        label_16->setText(QApplication::translate("GGA", "<html><head/><body><p><span style=\" color:#8ae234;\">Age of Differentiak GPS Data</span></p></body></html>", nullptr));
        label_18->setText(QApplication::translate("GGA", "<html><head/><body><p><span style=\" color:#8ae234;\">Diffrential Reference Station ID</span></p></body></html>", nullptr));
        pushButton_3->setText(QApplication::translate("GGA", "ON", nullptr));
        pushButton_4->setText(QApplication::translate("GGA", "OFF", nullptr));
    } // retranslateUi

};

namespace Ui {
    class GGA: public Ui_GGA {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GGA_H
