/********************************************************************************
** Form generated from reading UI file 'ECHO.ui'
**
** Created by: Qt User Interface Compiler version 5.12.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ECHO_H
#define UI_ECHO_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>

QT_BEGIN_NAMESPACE

class Ui_ECHO
{
public:
    QComboBox *Depth_combo;
    QDoubleSpinBox *Depth_spin;
    QLabel *label_4;
    QPushButton *LOG_confirmn;
    QGroupBox *topBox;
    QLabel *label;
    QLabel *label_2;
    QRadioButton *radioButton_19;
    QRadioButton *radioButton_20;
    QRadioButton *radioButton_21;
    QLabel *label_3;
    QPushButton *LOG_cancel;
    QPushButton *pushButton;
    QPushButton *pushButton_2;

    void setupUi(QFrame *ECHO)
    {
        if (ECHO->objectName().isEmpty())
            ECHO->setObjectName(QString::fromUtf8("ECHO"));
        ECHO->resize(600, 600);
        ECHO->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);"));
        Depth_combo = new QComboBox(ECHO);
        Depth_combo->addItem(QString());
        Depth_combo->addItem(QString());
        Depth_combo->addItem(QString());
        Depth_combo->setObjectName(QString::fromUtf8("Depth_combo"));
        Depth_combo->setGeometry(QRect(356, 245, 140, 26));
        Depth_combo->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        Depth_spin = new QDoubleSpinBox(ECHO);
        Depth_spin->setObjectName(QString::fromUtf8("Depth_spin"));
        Depth_spin->setGeometry(QRect(140, 243, 120, 30));
        Depth_spin->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        Depth_spin->setMaximum(100.000000000000000);
        label_4 = new QLabel(ECHO);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(260, 250, 80, 18));
        LOG_confirmn = new QPushButton(ECHO);
        LOG_confirmn->setObjectName(QString::fromUtf8("LOG_confirmn"));
        LOG_confirmn->setGeometry(QRect(180, 300, 94, 26));
        LOG_confirmn->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        topBox = new QGroupBox(ECHO);
        topBox->setObjectName(QString::fromUtf8("topBox"));
        topBox->setGeometry(QRect(10, 90, 550, 120));
        topBox->setStyleSheet(QString::fromUtf8("background-color: rgb(136, 138, 133);\n"
"background-color: rgb(46, 52, 54);"));
        label = new QLabel(topBox);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(40, 34, 66, 18));
        label_2 = new QLabel(topBox);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(40, 84, 66, 18));
        radioButton_19 = new QRadioButton(topBox);
        radioButton_19->setObjectName(QString::fromUtf8("radioButton_19"));
        radioButton_19->setGeometry(QRect(140, 84, 81, 23));
        radioButton_19->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        radioButton_20 = new QRadioButton(topBox);
        radioButton_20->setObjectName(QString::fromUtf8("radioButton_20"));
        radioButton_20->setGeometry(QRect(250, 80, 110, 23));
        radioButton_20->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        radioButton_21 = new QRadioButton(topBox);
        radioButton_21->setObjectName(QString::fromUtf8("radioButton_21"));
        radioButton_21->setGeometry(QRect(390, 80, 110, 23));
        radioButton_21->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        label_3 = new QLabel(ECHO);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(80, 250, 51, 18));
        LOG_cancel = new QPushButton(ECHO);
        LOG_cancel->setObjectName(QString::fromUtf8("LOG_cancel"));
        LOG_cancel->setGeometry(QRect(280, 300, 94, 26));
        LOG_cancel->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        pushButton = new QPushButton(ECHO);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(190, 340, 84, 28));
        pushButton->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        pushButton_2 = new QPushButton(ECHO);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(280, 340, 84, 28));
        pushButton_2->setStyleSheet(QString::fromUtf8("background-color: rgb(239, 41, 41);"));

        retranslateUi(ECHO);

        QMetaObject::connectSlotsByName(ECHO);
    } // setupUi

    void retranslateUi(QFrame *ECHO)
    {
        ECHO->setWindowTitle(QApplication::translate("ECHO", "Frame", nullptr));
        Depth_combo->setItemText(0, QApplication::translate("ECHO", "Meters", nullptr));
        Depth_combo->setItemText(1, QApplication::translate("ECHO", "Feet", nullptr));
        Depth_combo->setItemText(2, QApplication::translate("ECHO", "Fathoms", nullptr));

        label_4->setText(QApplication::translate("ECHO", "<html><head/><body><p><span style=\" color:#8ae234;\">(0-100)</span></p></body></html>", nullptr));
        LOG_confirmn->setText(QApplication::translate("ECHO", "Confirm", nullptr));
        topBox->setTitle(QString());
        label->setText(QApplication::translate("ECHO", "<html><head/><body><p><span style=\" color:#8ae234;\">Channel:</span></p></body></html>", nullptr));
        label_2->setText(QApplication::translate("ECHO", "<html><head/><body><p><span style=\" color:#8ae234;\">Garbel -</span></p></body></html>", nullptr));
        radioButton_19->setText(QApplication::translate("ECHO", "OFF", nullptr));
        radioButton_20->setText(QApplication::translate("ECHO", "GARBLE 1", nullptr));
        radioButton_21->setText(QApplication::translate("ECHO", "GARBLE 2", nullptr));
        label_3->setText(QApplication::translate("ECHO", "<html><head/><body><p><span style=\" color:#8ae234;\">Depth:</span></p></body></html>", nullptr));
        LOG_cancel->setText(QApplication::translate("ECHO", "Cancel", nullptr));
        pushButton->setText(QApplication::translate("ECHO", "ON", nullptr));
        pushButton_2->setText(QApplication::translate("ECHO", "OFF", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ECHO: public Ui_ECHO {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ECHO_H
