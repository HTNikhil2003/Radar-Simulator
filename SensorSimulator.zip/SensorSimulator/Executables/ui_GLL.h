/********************************************************************************
** Form generated from reading UI file 'GLL.ui'
**
** Created by: Qt User Interface Compiler version 5.12.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GLL_H
#define UI_GLL_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_GLL
{
public:
    QGroupBox *groupBox;
    QLabel *label_8;
    QDoubleSpinBox *doubleSpinBox_4;
    QLabel *label_6;
    QLabel *label_9;
    QLabel *label_3;
    QLabel *label_2;
    QLabel *label_5;
    QDoubleSpinBox *doubleSpinBox_3;
    QLabel *label_7;
    QLabel *label_4;
    QTextEdit *textEdit;
    QTextEdit *textEdit_2;
    QSpinBox *spinBox_11;
    QSpinBox *spinBox_4;
    QComboBox *comboBox_2;
    QComboBox *comboBox_3;
    QLabel *label_10;
    QGroupBox *groupBox_2;
    QLabel *label;
    QLabel *label_12;
    QSpinBox *spinBox;
    QSpinBox *spinBox_2;
    QSpinBox *spinBox_3;
    QComboBox *comboBox;
    QLabel *label_15;
    QLabel *label_16;
    QLabel *label_17;
    QGroupBox *groupBox_3;
    QRadioButton *radioButton;
    QRadioButton *radioButton_2;
    QComboBox *comboBox_4;
    QLabel *label_11;
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;

    void setupUi(QFrame *GLL)
    {
        if (GLL->objectName().isEmpty())
            GLL->setObjectName(QString::fromUtf8("GLL"));
        GLL->resize(600, 600);
        GLL->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);"));
        groupBox = new QGroupBox(GLL);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setGeometry(QRect(10, 10, 601, 181));
        groupBox->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);"));
        label_8 = new QLabel(groupBox);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setGeometry(QRect(400, 30, 63, 20));
        doubleSpinBox_4 = new QDoubleSpinBox(groupBox);
        doubleSpinBox_4->setObjectName(QString::fromUtf8("doubleSpinBox_4"));
        doubleSpinBox_4->setGeometry(QRect(270, 120, 101, 29));
        doubleSpinBox_4->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        doubleSpinBox_4->setAlignment(Qt::AlignCenter);
        label_6 = new QLabel(groupBox);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(270, 30, 111, 20));
        label_9 = new QLabel(groupBox);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setGeometry(QRect(400, 100, 63, 20));
        label_3 = new QLabel(groupBox);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(80, 110, 71, 20));
        label_2 = new QLabel(groupBox);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(80, 50, 63, 20));
        label_5 = new QLabel(groupBox);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(180, 100, 71, 20));
        doubleSpinBox_3 = new QDoubleSpinBox(groupBox);
        doubleSpinBox_3->setObjectName(QString::fromUtf8("doubleSpinBox_3"));
        doubleSpinBox_3->setGeometry(QRect(270, 50, 101, 29));
        doubleSpinBox_3->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        doubleSpinBox_3->setAlignment(Qt::AlignCenter);
        label_7 = new QLabel(groupBox);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(270, 100, 111, 20));
        label_4 = new QLabel(groupBox);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(180, 30, 63, 20));
        textEdit = new QTextEdit(groupBox);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));
        textEdit->setGeometry(QRect(440, 50, 21, 20));
        textEdit->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        textEdit_2 = new QTextEdit(groupBox);
        textEdit_2->setObjectName(QString::fromUtf8("textEdit_2"));
        textEdit_2->setGeometry(QRect(440, 130, 21, 16));
        textEdit_2->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        spinBox_11 = new QSpinBox(groupBox);
        spinBox_11->setObjectName(QString::fromUtf8("spinBox_11"));
        spinBox_11->setGeometry(QRect(180, 120, 49, 29));
        spinBox_11->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        spinBox_4 = new QSpinBox(groupBox);
        spinBox_4->setObjectName(QString::fromUtf8("spinBox_4"));
        spinBox_4->setGeometry(QRect(180, 50, 49, 29));
        spinBox_4->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        comboBox_2 = new QComboBox(groupBox);
        comboBox_2->addItem(QString());
        comboBox_2->addItem(QString());
        comboBox_2->setObjectName(QString::fromUtf8("comboBox_2"));
        comboBox_2->setGeometry(QRect(400, 50, 79, 28));
        comboBox_2->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        comboBox_3 = new QComboBox(groupBox);
        comboBox_3->addItem(QString());
        comboBox_3->addItem(QString());
        comboBox_3->setObjectName(QString::fromUtf8("comboBox_3"));
        comboBox_3->setGeometry(QRect(400, 120, 79, 28));
        comboBox_3->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        label_10 = new QLabel(groupBox);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setGeometry(QRect(0, 0, 111, 20));
        groupBox_2 = new QGroupBox(GLL);
        groupBox_2->setObjectName(QString::fromUtf8("groupBox_2"));
        groupBox_2->setGeometry(QRect(10, 200, 601, 151));
        groupBox_2->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);"));
        label = new QLabel(groupBox_2);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(60, 40, 111, 20));
        label_12 = new QLabel(groupBox_2);
        label_12->setObjectName(QString::fromUtf8("label_12"));
        label_12->setGeometry(QRect(60, 110, 101, 20));
        spinBox = new QSpinBox(groupBox_2);
        spinBox->setObjectName(QString::fromUtf8("spinBox"));
        spinBox->setGeometry(QRect(190, 50, 71, 29));
        spinBox->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        spinBox->setAlignment(Qt::AlignCenter);
        spinBox->setValue(12);
        spinBox_2 = new QSpinBox(groupBox_2);
        spinBox_2->setObjectName(QString::fromUtf8("spinBox_2"));
        spinBox_2->setGeometry(QRect(290, 50, 71, 29));
        spinBox_2->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        spinBox_2->setAlignment(Qt::AlignCenter);
        spinBox_3 = new QSpinBox(groupBox_2);
        spinBox_3->setObjectName(QString::fromUtf8("spinBox_3"));
        spinBox_3->setGeometry(QRect(390, 50, 71, 29));
        spinBox_3->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        spinBox_3->setAlignment(Qt::AlignCenter);
        comboBox = new QComboBox(groupBox_2);
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->setObjectName(QString::fromUtf8("comboBox"));
        comboBox->setGeometry(QRect(190, 110, 191, 28));
        comboBox->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        label_15 = new QLabel(groupBox_2);
        label_15->setObjectName(QString::fromUtf8("label_15"));
        label_15->setGeometry(QRect(200, 30, 63, 20));
        label_16 = new QLabel(groupBox_2);
        label_16->setObjectName(QString::fromUtf8("label_16"));
        label_16->setGeometry(QRect(290, 30, 71, 20));
        label_17 = new QLabel(groupBox_2);
        label_17->setObjectName(QString::fromUtf8("label_17"));
        label_17->setGeometry(QRect(390, 30, 63, 20));
        groupBox_3 = new QGroupBox(GLL);
        groupBox_3->setObjectName(QString::fromUtf8("groupBox_3"));
        groupBox_3->setGeometry(QRect(10, 360, 601, 101));
        groupBox_3->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);"));
        radioButton = new QRadioButton(groupBox_3);
        radioButton->setObjectName(QString::fromUtf8("radioButton"));
        radioButton->setGeometry(QRect(210, 50, 106, 26));
        radioButton_2 = new QRadioButton(groupBox_3);
        radioButton_2->setObjectName(QString::fromUtf8("radioButton_2"));
        radioButton_2->setGeometry(QRect(210, 50, 106, 26));
        comboBox_4 = new QComboBox(groupBox_3);
        comboBox_4->addItem(QString());
        comboBox_4->addItem(QString());
        comboBox_4->setObjectName(QString::fromUtf8("comboBox_4"));
        comboBox_4->setGeometry(QRect(200, 50, 131, 28));
        comboBox_4->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        label_11 = new QLabel(groupBox_3);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        label_11->setGeometry(QRect(0, 0, 111, 20));
        layoutWidget = new QWidget(GLL);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(160, 459, 281, 41));
        horizontalLayout = new QHBoxLayout(layoutWidget);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        pushButton = new QPushButton(layoutWidget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));

        horizontalLayout->addWidget(pushButton);

        pushButton_2 = new QPushButton(layoutWidget);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));

        horizontalLayout->addWidget(pushButton_2);

        pushButton_3 = new QPushButton(GLL);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setGeometry(QRect(210, 500, 84, 28));
        pushButton_3->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        pushButton_4 = new QPushButton(GLL);
        pushButton_4->setObjectName(QString::fromUtf8("pushButton_4"));
        pushButton_4->setGeometry(QRect(300, 500, 84, 28));
        pushButton_4->setStyleSheet(QString::fromUtf8("background-color: rgb(239, 41, 41);"));

        retranslateUi(GLL);

        QMetaObject::connectSlotsByName(GLL);
    } // setupUi

    void retranslateUi(QFrame *GLL)
    {
        GLL->setWindowTitle(QApplication::translate("GLL", "Frame", nullptr));
        groupBox->setTitle(QApplication::translate("GLL", "Position:", nullptr));
        label_8->setText(QApplication::translate("GLL", "<html><head/><body><p><span style=\" color:#8ae234;\">  Dir(N/S)</span></p></body></html>", nullptr));
        label_6->setText(QApplication::translate("GLL", "<html><head/><body><p><span style=\" color:#8ae234;\">MM.MM(59.59)</span></p></body></html>", nullptr));
        label_9->setText(QApplication::translate("GLL", "<html><head/><body><p><span style=\" color:#8ae234;\"> Dir(E/W)</span></p></body></html>", nullptr));
        label_3->setText(QApplication::translate("GLL", "<html><head/><body><p><span style=\" color:#8ae234;\">Longitude</span></p></body></html>", nullptr));
        label_2->setText(QApplication::translate("GLL", "<html><head/><body><p><span style=\" color:#8ae234;\">Latitude</span></p></body></html>", nullptr));
        label_5->setText(QApplication::translate("GLL", "<html><head/><body><p><span style=\" color:#8ae234;\">DD(0-90)</span></p></body></html>", nullptr));
        label_7->setText(QApplication::translate("GLL", "<html><head/><body><p><span style=\" color:#8ae234;\">MM.MM(59.59)</span></p></body></html>", nullptr));
        label_4->setText(QApplication::translate("GLL", "<html><head/><body><p><span style=\" color:#8ae234;\">DD(0-90)</span></p></body></html>", nullptr));
        comboBox_2->setItemText(0, QApplication::translate("GLL", "N", nullptr));
        comboBox_2->setItemText(1, QApplication::translate("GLL", "S", nullptr));

        comboBox_3->setItemText(0, QApplication::translate("GLL", "E", nullptr));
        comboBox_3->setItemText(1, QApplication::translate("GLL", "W", nullptr));

        label_10->setText(QApplication::translate("GLL", "<html><head/><body><p><span style=\" color:#8ae234;\">Position:</span></p></body></html>", nullptr));
        groupBox_2->setTitle(QString());
        label->setText(QApplication::translate("GLL", "<html><head/><body><p><span style=\" color:#8ae234;\">UTC Of Position:</span></p></body></html>", nullptr));
        label_12->setText(QApplication::translate("GLL", "<html><head/><body><p><span style=\" color:#8ae234;\">Mode indicator:</span></p></body></html>", nullptr));
        comboBox->setItemText(0, QApplication::translate("GLL", "Autonomous", nullptr));
        comboBox->setItemText(1, QApplication::translate("GLL", "Non-autonomous", nullptr));
        comboBox->setItemText(2, QApplication::translate("GLL", "Normal mode", nullptr));

        label_15->setText(QApplication::translate("GLL", "<html><head/><body><p><span style=\" color:#8ae234;\">HH(0-23)</span></p></body></html>", nullptr));
        label_16->setText(QApplication::translate("GLL", "<html><head/><body><p><span style=\" color:#8ae234;\">MM(0-59)</span></p></body></html>", nullptr));
        label_17->setText(QApplication::translate("GLL", "<html><head/><body><p><span style=\" color:#8ae234;\">SS(0-59)</span></p></body></html>", nullptr));
        groupBox_3->setTitle(QApplication::translate("GLL", "Status:", nullptr));
        radioButton->setText(QApplication::translate("GLL", "Valid", nullptr));
        radioButton_2->setText(QApplication::translate("GLL", "Invalid", nullptr));
        comboBox_4->setItemText(0, QApplication::translate("GLL", "A", nullptr));
        comboBox_4->setItemText(1, QApplication::translate("GLL", "V", nullptr));

        label_11->setText(QApplication::translate("GLL", "<html><head/><body><p><span style=\" color:#8ae234;\">Status:</span></p></body></html>", nullptr));
        pushButton->setText(QApplication::translate("GLL", "Confirm", nullptr));
        pushButton_2->setText(QApplication::translate("GLL", "Clear", nullptr));
        pushButton_3->setText(QApplication::translate("GLL", "ON", nullptr));
        pushButton_4->setText(QApplication::translate("GLL", "OFF", nullptr));
    } // retranslateUi

};

namespace Ui {
    class GLL: public Ui_GLL {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GLL_H
