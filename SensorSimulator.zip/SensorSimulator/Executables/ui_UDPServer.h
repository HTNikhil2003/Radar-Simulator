/********************************************************************************
** Form generated from reading UI file 'UDPServer.ui'
**
** Created by: Qt User Interface Compiler version 5.12.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_UDPSERVER_H
#define UI_UDPSERVER_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>

QT_BEGIN_NAMESPACE

class Ui_UDPServer
{
public:
    QTextEdit *SenderText;
    QTextEdit *ReceiverText;
    QLabel *label;
    QLabel *label_2;
    QPushButton *pushButton;
    QComboBox *comboBox;

    void setupUi(QFrame *UDPServer)
    {
        if (UDPServer->objectName().isEmpty())
            UDPServer->setObjectName(QString::fromUtf8("UDPServer"));
        UDPServer->setEnabled(true);
        UDPServer->resize(337, 222);
        SenderText = new QTextEdit(UDPServer);
        SenderText->setObjectName(QString::fromUtf8("SenderText"));
        SenderText->setGeometry(QRect(20, 140, 131, 31));
        ReceiverText = new QTextEdit(UDPServer);
        ReceiverText->setObjectName(QString::fromUtf8("ReceiverText"));
        ReceiverText->setGeometry(QRect(180, 140, 131, 31));
        label = new QLabel(UDPServer);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(40, 110, 91, 20));
        label_2 = new QLabel(UDPServer);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(190, 110, 101, 20));
        pushButton = new QPushButton(UDPServer);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(120, 190, 84, 28));
        comboBox = new QComboBox(UDPServer);
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->setObjectName(QString::fromUtf8("comboBox"));
        comboBox->setGeometry(QRect(18, 30, 191, 28));

        retranslateUi(UDPServer);

        QMetaObject::connectSlotsByName(UDPServer);
    } // setupUi

    void retranslateUi(QFrame *UDPServer)
    {
        UDPServer->setWindowTitle(QApplication::translate("UDPServer", "Frame", nullptr));
        label->setText(QApplication::translate("UDPServer", "Sender's port", nullptr));
        label_2->setText(QApplication::translate("UDPServer", "Receiver's port", nullptr));
        pushButton->setText(QApplication::translate("UDPServer", "SEND", nullptr));
        comboBox->setItemText(0, QApplication::translate("UDPServer", "Select", nullptr));
        comboBox->setItemText(1, QApplication::translate("UDPServer", "Uni-cast", nullptr));
        comboBox->setItemText(2, QApplication::translate("UDPServer", "Broad-cast", nullptr));

    } // retranslateUi

};

namespace Ui {
    class UDPServer: public Ui_UDPServer {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_UDPSERVER_H
