/****************************************************************************
** Meta object code from reading C++ file 'GGA.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../GPS/GGA.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'GGA.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_GGA_t {
    QByteArrayData data[15];
    char stringdata0[180];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_GGA_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_GGA_t qt_meta_stringdata_GGA = {
    {
QT_MOC_LITERAL(0, 0, 3), // "GGA"
QT_MOC_LITERAL(1, 4, 12), // "sendSentence"
QT_MOC_LITERAL(2, 17, 0), // ""
QT_MOC_LITERAL(3, 18, 8), // "sentence"
QT_MOC_LITERAL(4, 27, 14), // "updatePosition"
QT_MOC_LITERAL(5, 42, 5), // "latDD"
QT_MOC_LITERAL(6, 48, 5), // "latMM"
QT_MOC_LITERAL(7, 54, 5), // "lonDD"
QT_MOC_LITERAL(8, 60, 5), // "lonMM"
QT_MOC_LITERAL(9, 66, 21), // "on_pushButton_clicked"
QT_MOC_LITERAL(10, 88, 23), // "on_pushButton_2_clicked"
QT_MOC_LITERAL(11, 112, 11), // "updateGPGGA"
QT_MOC_LITERAL(12, 124, 7), // "sendGGA"
QT_MOC_LITERAL(13, 132, 23), // "on_pushButton_3_clicked"
QT_MOC_LITERAL(14, 156, 23) // "on_pushButton_4_clicked"

    },
    "GGA\0sendSentence\0\0sentence\0updatePosition\0"
    "latDD\0latMM\0lonDD\0lonMM\0on_pushButton_clicked\0"
    "on_pushButton_2_clicked\0updateGPGGA\0"
    "sendGGA\0on_pushButton_3_clicked\0"
    "on_pushButton_4_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_GGA[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       8,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   54,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       4,    4,   57,    2, 0x0a /* Public */,
       9,    0,   66,    2, 0x08 /* Private */,
      10,    0,   67,    2, 0x08 /* Private */,
      11,    0,   68,    2, 0x08 /* Private */,
      12,    0,   69,    2, 0x08 /* Private */,
      13,    0,   70,    2, 0x08 /* Private */,
      14,    0,   71,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void, QMetaType::QString,    3,

 // slots: parameters
    QMetaType::Void, QMetaType::Int, QMetaType::Double, QMetaType::Int, QMetaType::Double,    5,    6,    7,    8,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void GGA::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        GGA *_t = static_cast<GGA *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->sendSentence((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 1: _t->updatePosition((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3])),(*reinterpret_cast< double(*)>(_a[4]))); break;
        case 2: _t->on_pushButton_clicked(); break;
        case 3: _t->on_pushButton_2_clicked(); break;
        case 4: _t->updateGPGGA(); break;
        case 5: _t->sendGGA(); break;
        case 6: _t->on_pushButton_3_clicked(); break;
        case 7: _t->on_pushButton_4_clicked(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (GGA::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&GGA::sendSentence)) {
                *result = 0;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject GGA::staticMetaObject = { {
    &QFrame::staticMetaObject,
    qt_meta_stringdata_GGA.data,
    qt_meta_data_GGA,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *GGA::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *GGA::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_GGA.stringdata0))
        return static_cast<void*>(this);
    return QFrame::qt_metacast(_clname);
}

int GGA::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QFrame::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 8)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 8;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 8)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 8;
    }
    return _id;
}

// SIGNAL 0
void GGA::sendSentence(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
