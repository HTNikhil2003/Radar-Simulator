/********************************************************************************
** Form generated from reading UI file 'MWV.ui'
**
** Created by: Qt User Interface Compiler version 5.12.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MWV_H
#define UI_MWV_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>

QT_BEGIN_NAMESPACE

class Ui_MWV
{
public:
    QGroupBox *topBox;
    QLabel *label_5;
    QLabel *label_6;
    QRadioButton *radioButton_26;
    QRadioButton *radioButton_27;
    QRadioButton *radioButton_28;
    QGroupBox *groupBox_4;
    QRadioButton *status_Valid;
    QRadioButton *status_Invalid;
    QLabel *label;
    QPushButton *MWV_confirm;
    QPushButton *MWV_cancel;
    QLabel *label_2;
    QDoubleSpinBox *waterSpeed;
    QLabel *label_3;
    QGroupBox *groupBox;
    QRadioButton *rb_Kn;
    QRadioButton *rb_kmph;
    QRadioButton *rb_mps;
    QLabel *label_4;
    QGroupBox *groupBox_3;
    QRadioButton *wind_RefTrue;
    QRadioButton *wind_RefRelative;
    QDoubleSpinBox *waterAngle;
    QPushButton *pushButton;
    QPushButton *pushButton_3;

    void setupUi(QFrame *MWV)
    {
        if (MWV->objectName().isEmpty())
            MWV->setObjectName(QString::fromUtf8("MWV"));
        MWV->resize(600, 600);
        MWV->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);"));
        topBox = new QGroupBox(MWV);
        topBox->setObjectName(QString::fromUtf8("topBox"));
        topBox->setGeometry(QRect(30, 390, 561, 111));
        topBox->setStyleSheet(QString::fromUtf8("background-color: rgb(136, 138, 133);\n"
"background-color: rgb(46, 52, 54);"));
        label_5 = new QLabel(topBox);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(40, 34, 16, 18));
        label_6 = new QLabel(topBox);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(40, 60, 66, 18));
        radioButton_26 = new QRadioButton(topBox);
        radioButton_26->setObjectName(QString::fromUtf8("radioButton_26"));
        radioButton_26->setGeometry(QRect(140, 60, 81, 23));
        radioButton_26->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        radioButton_27 = new QRadioButton(topBox);
        radioButton_27->setObjectName(QString::fromUtf8("radioButton_27"));
        radioButton_27->setGeometry(QRect(380, 60, 110, 23));
        radioButton_27->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        radioButton_28 = new QRadioButton(topBox);
        radioButton_28->setObjectName(QString::fromUtf8("radioButton_28"));
        radioButton_28->setGeometry(QRect(250, 60, 110, 23));
        radioButton_28->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        groupBox_4 = new QGroupBox(MWV);
        groupBox_4->setObjectName(QString::fromUtf8("groupBox_4"));
        groupBox_4->setGeometry(QRect(34, 292, 561, 90));
        groupBox_4->setStyleSheet(QString::fromUtf8("background-color: rgb(136, 138, 133);\n"
"background-color: rgb(46, 52, 54);"));
        status_Valid = new QRadioButton(groupBox_4);
        status_Valid->setObjectName(QString::fromUtf8("status_Valid"));
        status_Valid->setGeometry(QRect(140, 50, 110, 23));
        status_Valid->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        status_Invalid = new QRadioButton(groupBox_4);
        status_Invalid->setObjectName(QString::fromUtf8("status_Invalid"));
        status_Invalid->setGeometry(QRect(270, 51, 110, 23));
        status_Invalid->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        label = new QLabel(MWV);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(30, 12, 90, 18));
        MWV_confirm = new QPushButton(MWV);
        MWV_confirm->setObjectName(QString::fromUtf8("MWV_confirm"));
        MWV_confirm->setGeometry(QRect(220, 520, 94, 26));
        MWV_confirm->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        MWV_cancel = new QPushButton(MWV);
        MWV_cancel->setObjectName(QString::fromUtf8("MWV_cancel"));
        MWV_cancel->setGeometry(QRect(320, 520, 94, 26));
        MWV_cancel->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        label_2 = new QLabel(MWV);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(30, 53, 90, 20));
        waterSpeed = new QDoubleSpinBox(MWV);
        waterSpeed->setObjectName(QString::fromUtf8("waterSpeed"));
        waterSpeed->setGeometry(QRect(200, 50, 130, 27));
        waterSpeed->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        waterSpeed->setMaximum(100.000000000000000);
        label_3 = new QLabel(MWV);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(340, 14, 120, 18));
        groupBox = new QGroupBox(MWV);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setGeometry(QRect(30, 94, 561, 81));
        groupBox->setStyleSheet(QString::fromUtf8("background-color: rgb(136, 138, 133);\n"
"background-color: rgb(46, 52, 54);"));
        rb_Kn = new QRadioButton(groupBox);
        rb_Kn->setObjectName(QString::fromUtf8("rb_Kn"));
        rb_Kn->setGeometry(QRect(30, 40, 110, 23));
        rb_Kn->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        rb_kmph = new QRadioButton(groupBox);
        rb_kmph->setObjectName(QString::fromUtf8("rb_kmph"));
        rb_kmph->setGeometry(QRect(399, 40, 110, 23));
        rb_kmph->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        rb_mps = new QRadioButton(groupBox);
        rb_mps->setObjectName(QString::fromUtf8("rb_mps"));
        rb_mps->setGeometry(QRect(210, 40, 110, 23));
        rb_mps->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        label_4 = new QLabel(MWV);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(340, 54, 110, 18));
        groupBox_3 = new QGroupBox(MWV);
        groupBox_3->setObjectName(QString::fromUtf8("groupBox_3"));
        groupBox_3->setGeometry(QRect(31, 190, 561, 90));
        groupBox_3->setStyleSheet(QString::fromUtf8("background-color: rgb(136, 138, 133);\n"
"background-color: rgb(46, 52, 54);"));
        wind_RefTrue = new QRadioButton(groupBox_3);
        wind_RefTrue->setObjectName(QString::fromUtf8("wind_RefTrue"));
        wind_RefTrue->setGeometry(QRect(140, 50, 110, 23));
        wind_RefTrue->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        wind_RefRelative = new QRadioButton(groupBox_3);
        wind_RefRelative->setObjectName(QString::fromUtf8("wind_RefRelative"));
        wind_RefRelative->setGeometry(QRect(270, 51, 110, 23));
        wind_RefRelative->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        waterAngle = new QDoubleSpinBox(MWV);
        waterAngle->setObjectName(QString::fromUtf8("waterAngle"));
        waterAngle->setGeometry(QRect(200, 10, 130, 27));
        waterAngle->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        waterAngle->setMaximum(360.000000000000000);
        pushButton = new QPushButton(MWV);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(230, 560, 84, 28));
        pushButton->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        pushButton_3 = new QPushButton(MWV);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setGeometry(QRect(320, 560, 84, 28));
        pushButton_3->setStyleSheet(QString::fromUtf8("background-color: rgb(239, 41, 41);"));

        retranslateUi(MWV);

        QMetaObject::connectSlotsByName(MWV);
    } // setupUi

    void retranslateUi(QFrame *MWV)
    {
        MWV->setWindowTitle(QApplication::translate("MWV", "Frame", nullptr));
        topBox->setTitle(QApplication::translate("MWV", "Communications:", nullptr));
        label_5->setText(QString());
        label_6->setText(QApplication::translate("MWV", "Garble:", nullptr));
        radioButton_26->setText(QApplication::translate("MWV", "OFF", nullptr));
        radioButton_27->setText(QApplication::translate("MWV", "GARBLE 2", nullptr));
        radioButton_28->setText(QApplication::translate("MWV", "GARBLE 1", nullptr));
        groupBox_4->setTitle(QApplication::translate("MWV", "Status:", nullptr));
        status_Valid->setText(QApplication::translate("MWV", "Valid", nullptr));
        status_Invalid->setText(QApplication::translate("MWV", "Invalid", nullptr));
        label->setText(QApplication::translate("MWV", "<html><head/><body><p><span style=\" color:#8ae234;\">Water Angle:</span></p></body></html>", nullptr));
        MWV_confirm->setText(QApplication::translate("MWV", "Confirm", nullptr));
        MWV_cancel->setText(QApplication::translate("MWV", "Cancel", nullptr));
        label_2->setText(QApplication::translate("MWV", "<html><head/><body><p><span style=\" color:#8ae234;\">Water Speed:</span></p></body></html>", nullptr));
        label_3->setText(QApplication::translate("MWV", "<html><head/><body><p><span style=\" color:#8ae234;\">Deg (0.0 - 359.9)</span></p></body></html>", nullptr));
        groupBox->setTitle(QApplication::translate("MWV", "Speed Units:", nullptr));
        rb_Kn->setText(QApplication::translate("MWV", "Kn", nullptr));
        rb_kmph->setText(QApplication::translate("MWV", "Km", nullptr));
        rb_mps->setText(QApplication::translate("MWV", "M", nullptr));
        label_4->setText(QApplication::translate("MWV", "<html><head/><body><p><span style=\" color:#8ae234;\">Kn(0.0 - 100.0)</span></p></body></html>", nullptr));
        groupBox_3->setTitle(QApplication::translate("MWV", "Wind Reference:", nullptr));
        wind_RefTrue->setText(QApplication::translate("MWV", "True", nullptr));
        wind_RefRelative->setText(QApplication::translate("MWV", "Relative", nullptr));
        pushButton->setText(QApplication::translate("MWV", "ON", nullptr));
        pushButton_3->setText(QApplication::translate("MWV", "OFF", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MWV: public Ui_MWV {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MWV_H
