/********************************************************************************
** Form generated from reading UI file 'XDR.ui'
**
** Created by: Qt User Interface Compiler version 5.12.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_XDR_H
#define UI_XDR_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>

QT_BEGIN_NAMESPACE

class Ui_XDR
{
public:
    QComboBox *cb_TranType;
    QPushButton *XDR_confirm;
    QDoubleSpinBox *sp_TranMeasurement;
    QLabel *label_2;
    QLabel *label_5;
    QPushButton *XDR_cancel;
    QLabel *label_4;
    QComboBox *cb_Unit;
    QLabel *label_3;
    QGroupBox *topBox;
    QLabel *label_6;
    QLabel *label_7;
    QRadioButton *radioButton_26;
    QRadioButton *radioButton_27;
    QRadioButton *radioButton_28;
    QComboBox *cb_Tid;
    QLabel *label;
    QPushButton *pushButton;
    QPushButton *pushButton_3;

    void setupUi(QFrame *XDR)
    {
        if (XDR->objectName().isEmpty())
            XDR->setObjectName(QString::fromUtf8("XDR"));
        XDR->resize(600, 600);
        XDR->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);"));
        cb_TranType = new QComboBox(XDR);
        cb_TranType->addItem(QString());
        cb_TranType->addItem(QString());
        cb_TranType->addItem(QString());
        cb_TranType->addItem(QString());
        cb_TranType->addItem(QString());
        cb_TranType->addItem(QString());
        cb_TranType->addItem(QString());
        cb_TranType->addItem(QString());
        cb_TranType->addItem(QString());
        cb_TranType->addItem(QString());
        cb_TranType->addItem(QString());
        cb_TranType->addItem(QString());
        cb_TranType->addItem(QString());
        cb_TranType->addItem(QString());
        cb_TranType->addItem(QString());
        cb_TranType->setObjectName(QString::fromUtf8("cb_TranType"));
        cb_TranType->setGeometry(QRect(240, 60, 191, 26));
        cb_TranType->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        XDR_confirm = new QPushButton(XDR);
        XDR_confirm->setObjectName(QString::fromUtf8("XDR_confirm"));
        XDR_confirm->setGeometry(QRect(200, 390, 100, 26));
        XDR_confirm->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        sp_TranMeasurement = new QDoubleSpinBox(XDR);
        sp_TranMeasurement->setObjectName(QString::fromUtf8("sp_TranMeasurement"));
        sp_TranMeasurement->setGeometry(QRect(244, 111, 191, 27));
        sp_TranMeasurement->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        sp_TranMeasurement->setDecimals(1);
        sp_TranMeasurement->setMaximum(1000.000000000000000);
        label_2 = new QLabel(XDR);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(50, 118, 161, 16));
        label_5 = new QLabel(XDR);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(460, 117, 101, 16));
        XDR_cancel = new QPushButton(XDR);
        XDR_cancel->setObjectName(QString::fromUtf8("XDR_cancel"));
        XDR_cancel->setGeometry(QRect(310, 390, 100, 26));
        XDR_cancel->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        label_4 = new QLabel(XDR);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(80, 214, 161, 16));
        cb_Unit = new QComboBox(XDR);
        cb_Unit->addItem(QString());
        cb_Unit->addItem(QString());
        cb_Unit->addItem(QString());
        cb_Unit->addItem(QString());
        cb_Unit->addItem(QString());
        cb_Unit->addItem(QString());
        cb_Unit->addItem(QString());
        cb_Unit->addItem(QString());
        cb_Unit->addItem(QString());
        cb_Unit->addItem(QString());
        cb_Unit->addItem(QString());
        cb_Unit->addItem(QString());
        cb_Unit->addItem(QString());
        cb_Unit->addItem(QString());
        cb_Unit->addItem(QString());
        cb_Unit->addItem(QString());
        cb_Unit->addItem(QString());
        cb_Unit->setObjectName(QString::fromUtf8("cb_Unit"));
        cb_Unit->setGeometry(QRect(240, 164, 191, 26));
        cb_Unit->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        label_3 = new QLabel(XDR);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(70, 166, 161, 16));
        topBox = new QGroupBox(XDR);
        topBox->setObjectName(QString::fromUtf8("topBox"));
        topBox->setGeometry(QRect(30, 270, 550, 101));
        topBox->setStyleSheet(QString::fromUtf8("background-color: rgb(136, 138, 133);\n"
"background-color: rgb(46, 52, 54);"));
        topBox->setAlignment(Qt::AlignCenter);
        label_6 = new QLabel(topBox);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(10, 34, 16, 18));
        label_7 = new QLabel(topBox);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(40, 60, 66, 18));
        radioButton_26 = new QRadioButton(topBox);
        radioButton_26->setObjectName(QString::fromUtf8("radioButton_26"));
        radioButton_26->setGeometry(QRect(140, 60, 81, 23));
        radioButton_26->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        radioButton_27 = new QRadioButton(topBox);
        radioButton_27->setObjectName(QString::fromUtf8("radioButton_27"));
        radioButton_27->setGeometry(QRect(380, 60, 110, 23));
        radioButton_27->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        radioButton_28 = new QRadioButton(topBox);
        radioButton_28->setObjectName(QString::fromUtf8("radioButton_28"));
        radioButton_28->setGeometry(QRect(250, 60, 110, 23));
        radioButton_28->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        cb_Tid = new QComboBox(XDR);
        cb_Tid->addItem(QString());
        cb_Tid->addItem(QString());
        cb_Tid->addItem(QString());
        cb_Tid->addItem(QString());
        cb_Tid->addItem(QString());
        cb_Tid->setObjectName(QString::fromUtf8("cb_Tid"));
        cb_Tid->setGeometry(QRect(240, 210, 190, 26));
        cb_Tid->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        label = new QLabel(XDR);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(70, 70, 161, 16));
        pushButton = new QPushButton(XDR);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(220, 420, 84, 28));
        pushButton->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        pushButton_3 = new QPushButton(XDR);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setGeometry(QRect(310, 420, 84, 28));
        pushButton_3->setStyleSheet(QString::fromUtf8("background-color: rgb(239, 41, 41);"));

        retranslateUi(XDR);

        QMetaObject::connectSlotsByName(XDR);
    } // setupUi

    void retranslateUi(QFrame *XDR)
    {
        XDR->setWindowTitle(QApplication::translate("XDR", "Frame", nullptr));
        cb_TranType->setItemText(0, QApplication::translate("XDR", "C", nullptr));
        cb_TranType->setItemText(1, QApplication::translate("XDR", "A", nullptr));
        cb_TranType->setItemText(2, QApplication::translate("XDR", "D", nullptr));
        cb_TranType->setItemText(3, QApplication::translate("XDR", "F", nullptr));
        cb_TranType->setItemText(4, QApplication::translate("XDR", "N", nullptr));
        cb_TranType->setItemText(5, QApplication::translate("XDR", "P", nullptr));
        cb_TranType->setItemText(6, QApplication::translate("XDR", "R", nullptr));
        cb_TranType->setItemText(7, QApplication::translate("XDR", "T", nullptr));
        cb_TranType->setItemText(8, QApplication::translate("XDR", "H", nullptr));
        cb_TranType->setItemText(9, QApplication::translate("XDR", "V", nullptr));
        cb_TranType->setItemText(10, QApplication::translate("XDR", "G", nullptr));
        cb_TranType->setItemText(11, QApplication::translate("XDR", "I", nullptr));
        cb_TranType->setItemText(12, QApplication::translate("XDR", "U", nullptr));
        cb_TranType->setItemText(13, QApplication::translate("XDR", "S", nullptr));
        cb_TranType->setItemText(14, QApplication::translate("XDR", "L", nullptr));

        XDR_confirm->setText(QApplication::translate("XDR", "Confirm", nullptr));
        label_2->setText(QApplication::translate("XDR", "<html><head/><body><p><span style=\" color:#8ae234;\">Measurement Data</span></p></body></html>", nullptr));
        label_5->setText(QApplication::translate("XDR", "<html><head/><body><p><span style=\" color:#8ae234;\">(0.0 - 1000.0)</span></p></body></html>", nullptr));
        XDR_cancel->setText(QApplication::translate("XDR", "Cancel", nullptr));
        label_4->setText(QApplication::translate("XDR", "<html><head/><body><p><span style=\" color:#8ae234;\">Transducer ID</span></p></body></html>", nullptr));
        cb_Unit->setItemText(0, QApplication::translate("XDR", "Air Temp", nullptr));
        cb_Unit->setItemText(1, QApplication::translate("XDR", "Dew Point ", nullptr));
        cb_Unit->setItemText(2, QApplication::translate("XDR", "Angular Displacement", nullptr));
        cb_Unit->setItemText(3, QApplication::translate("XDR", "Linear Displacement ", nullptr));
        cb_Unit->setItemText(4, QApplication::translate("XDR", "Frequency", nullptr));
        cb_Unit->setItemText(5, QApplication::translate("XDR", "Flow Rate", nullptr));
        cb_Unit->setItemText(6, QApplication::translate("XDR", "Air Pressure", nullptr));
        cb_Unit->setItemText(7, QApplication::translate("XDR", "Tachometer", nullptr));
        cb_Unit->setItemText(8, QApplication::translate("XDR", "Relative Humidity", nullptr));
        cb_Unit->setItemText(9, QApplication::translate("XDR", "Volume", nullptr));
        cb_Unit->setItemText(10, QApplication::translate("XDR", "Generic", nullptr));
        cb_Unit->setItemText(11, QApplication::translate("XDR", "Current ", nullptr));
        cb_Unit->setItemText(12, QApplication::translate("XDR", "Voltage", nullptr));
        cb_Unit->setItemText(13, QApplication::translate("XDR", "Force", nullptr));
        cb_Unit->setItemText(14, QApplication::translate("XDR", "Switch / Valve", nullptr));
        cb_Unit->setItemText(15, QApplication::translate("XDR", "Salinity", nullptr));
        cb_Unit->setItemText(16, QApplication::translate("XDR", "Visibility", nullptr));

        label_3->setText(QApplication::translate("XDR", "<html><head/><body><p><span style=\" color:#8ae234;\">Unit of Measure</span></p></body></html>", nullptr));
        topBox->setTitle(QApplication::translate("XDR", "Communications", nullptr));
        label_6->setText(QString());
        label_7->setText(QApplication::translate("XDR", "<html><head/><body><p><span style=\" color:#8ae234;\">Garble:</span></p></body></html>", nullptr));
        radioButton_26->setText(QApplication::translate("XDR", "OFF", nullptr));
        radioButton_27->setText(QApplication::translate("XDR", "GARBLE 2", nullptr));
        radioButton_28->setText(QApplication::translate("XDR", "GARBLE 1", nullptr));
        cb_Tid->setItemText(0, QApplication::translate("XDR", "1", nullptr));
        cb_Tid->setItemText(1, QApplication::translate("XDR", "2", nullptr));
        cb_Tid->setItemText(2, QApplication::translate("XDR", "3", nullptr));
        cb_Tid->setItemText(3, QApplication::translate("XDR", "4", nullptr));
        cb_Tid->setItemText(4, QApplication::translate("XDR", "5", nullptr));

        label->setText(QApplication::translate("XDR", "<html><head/><body><p><span style=\" color:#8ae234;\">Transducer Type </span></p></body></html>", nullptr));
        pushButton->setText(QApplication::translate("XDR", "ON", nullptr));
        pushButton_3->setText(QApplication::translate("XDR", "OFF", nullptr));
    } // retranslateUi

};

namespace Ui {
    class XDR: public Ui_XDR {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_XDR_H
