/********************************************************************************
** Form generated from reading UI file 'Server.ui'
**
** Created by: Qt User Interface Compiler version 5.12.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SERVER_H
#define UI_SERVER_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Server
{
public:
    QTabWidget *TabWid1;
    QWidget *tab;
    QTextEdit *textEdit;
    QPushButton *pushButton;
    QWidget *tab_2;
    QPushButton *pushButton_2;
    QTextEdit *textEdit_2;

    void setupUi(QFrame *Server)
    {
        if (Server->objectName().isEmpty())
            Server->setObjectName(QString::fromUtf8("Server"));
        Server->resize(409, 408);
        TabWid1 = new QTabWidget(Server);
        TabWid1->setObjectName(QString::fromUtf8("TabWid1"));
        TabWid1->setGeometry(QRect(890, 150, 71, 211));
        tab = new QWidget();
        tab->setObjectName(QString::fromUtf8("tab"));
        textEdit = new QTextEdit(tab);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));
        textEdit->setGeometry(QRect(60, 20, 131, 101));
        pushButton = new QPushButton(tab);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(80, 130, 84, 28));
        TabWid1->addTab(tab, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QString::fromUtf8("tab_2"));
        pushButton_2 = new QPushButton(tab_2);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(80, 130, 84, 28));
        textEdit_2 = new QTextEdit(tab_2);
        textEdit_2->setObjectName(QString::fromUtf8("textEdit_2"));
        textEdit_2->setGeometry(QRect(60, 20, 131, 101));
        TabWid1->addTab(tab_2, QString());

        retranslateUi(Server);

        TabWid1->setCurrentIndex(1);


        QMetaObject::connectSlotsByName(Server);
    } // setupUi

    void retranslateUi(QFrame *Server)
    {
        Server->setWindowTitle(QApplication::translate("Server", "Frame", nullptr));
        pushButton->setText(QApplication::translate("Server", "Send", nullptr));
        TabWid1->setTabText(TabWid1->indexOf(tab), QApplication::translate("Server", "Sending", nullptr));
        pushButton_2->setText(QApplication::translate("Server", "Clear", nullptr));
        TabWid1->setTabText(TabWid1->indexOf(tab_2), QApplication::translate("Server", "Receive", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Server: public Ui_Server {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SERVER_H
