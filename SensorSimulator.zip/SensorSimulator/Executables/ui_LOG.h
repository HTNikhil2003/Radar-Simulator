/********************************************************************************
** Form generated from reading UI file 'LOG.ui'
**
** Created by: Qt User Interface Compiler version 5.12.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LOG_H
#define UI_LOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>

QT_BEGIN_NAMESPACE

class Ui_LOG
{
public:
    QPushButton *LOG_cancel;
    QGroupBox *waterBox;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QDoubleSpinBox *Water_Longitude;
    QDoubleSpinBox *Water_Transverse;
    QLabel *label_6;
    QLabel *label_7;
    QRadioButton *rb_Water_Valid;
    QRadioButton *rb_Water_Invalid;
    QLabel *label_49;
    QPushButton *LOG_confirmn;
    QGroupBox *groundBox;
    QLabel *label_43;
    QLabel *label_44;
    QLabel *label_45;
    QDoubleSpinBox *Ground_Longitude;
    QDoubleSpinBox *Ground_Transverse;
    QLabel *label_46;
    QLabel *label_47;
    QRadioButton *rb_Ground_Valid;
    QRadioButton *rb_Ground_Invalid;
    QLabel *label_48;
    QPushButton *pushButton;
    QPushButton *pushButton_2;

    void setupUi(QFrame *LOG)
    {
        if (LOG->objectName().isEmpty())
            LOG->setObjectName(QString::fromUtf8("LOG"));
        LOG->resize(680, 600);
        LOG->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);"));
        LOG_cancel = new QPushButton(LOG);
        LOG_cancel->setObjectName(QString::fromUtf8("LOG_cancel"));
        LOG_cancel->setGeometry(QRect(350, 410, 94, 26));
        LOG_cancel->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        waterBox = new QGroupBox(LOG);
        waterBox->setObjectName(QString::fromUtf8("waterBox"));
        waterBox->setGeometry(QRect(80, 30, 491, 160));
        waterBox->setStyleSheet(QString::fromUtf8("background-color: rgb(136, 138, 133);\n"
"background-color: rgb(46, 52, 54);"));
        waterBox->setAlignment(Qt::AlignCenter);
        label_3 = new QLabel(waterBox);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(25, 50, 91, 20));
        label_4 = new QLabel(waterBox);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(25, 90, 91, 20));
        label_5 = new QLabel(waterBox);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(30, 130, 66, 18));
        Water_Longitude = new QDoubleSpinBox(waterBox);
        Water_Longitude->setObjectName(QString::fromUtf8("Water_Longitude"));
        Water_Longitude->setGeometry(QRect(190, 50, 191, 27));
        Water_Longitude->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        Water_Transverse = new QDoubleSpinBox(waterBox);
        Water_Transverse->setObjectName(QString::fromUtf8("Water_Transverse"));
        Water_Transverse->setGeometry(QRect(190, 90, 191, 27));
        Water_Transverse->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        label_6 = new QLabel(waterBox);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(390, 50, 66, 18));
        label_7 = new QLabel(waterBox);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(390, 90, 66, 18));
        rb_Water_Valid = new QRadioButton(waterBox);
        rb_Water_Valid->setObjectName(QString::fromUtf8("rb_Water_Valid"));
        rb_Water_Valid->setGeometry(QRect(190, 130, 71, 23));
        rb_Water_Valid->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        rb_Water_Invalid = new QRadioButton(waterBox);
        rb_Water_Invalid->setObjectName(QString::fromUtf8("rb_Water_Invalid"));
        rb_Water_Invalid->setGeometry(QRect(310, 130, 71, 23));
        rb_Water_Invalid->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        label_49 = new QLabel(waterBox);
        label_49->setObjectName(QString::fromUtf8("label_49"));
        label_49->setGeometry(QRect(190, 0, 121, 21));
        LOG_confirmn = new QPushButton(LOG);
        LOG_confirmn->setObjectName(QString::fromUtf8("LOG_confirmn"));
        LOG_confirmn->setGeometry(QRect(240, 410, 94, 26));
        LOG_confirmn->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        groundBox = new QGroupBox(LOG);
        groundBox->setObjectName(QString::fromUtf8("groundBox"));
        groundBox->setGeometry(QRect(80, 230, 491, 160));
        groundBox->setStyleSheet(QString::fromUtf8("background-color: rgb(136, 138, 133);\n"
"background-color: rgb(46, 52, 54);"));
        groundBox->setAlignment(Qt::AlignCenter);
        label_43 = new QLabel(groundBox);
        label_43->setObjectName(QString::fromUtf8("label_43"));
        label_43->setGeometry(QRect(25, 49, 91, 31));
        label_44 = new QLabel(groundBox);
        label_44->setObjectName(QString::fromUtf8("label_44"));
        label_44->setGeometry(QRect(25, 90, 91, 21));
        label_45 = new QLabel(groundBox);
        label_45->setObjectName(QString::fromUtf8("label_45"));
        label_45->setGeometry(QRect(30, 130, 66, 18));
        Ground_Longitude = new QDoubleSpinBox(groundBox);
        Ground_Longitude->setObjectName(QString::fromUtf8("Ground_Longitude"));
        Ground_Longitude->setGeometry(QRect(190, 50, 191, 27));
        Ground_Longitude->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        Ground_Longitude->setDecimals(1);
        Ground_Longitude->setMaximum(99.000000000000000);
        Ground_Transverse = new QDoubleSpinBox(groundBox);
        Ground_Transverse->setObjectName(QString::fromUtf8("Ground_Transverse"));
        Ground_Transverse->setGeometry(QRect(190, 90, 191, 27));
        Ground_Transverse->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        Ground_Transverse->setDecimals(1);
        Ground_Transverse->setMaximum(99.000000000000000);
        label_46 = new QLabel(groundBox);
        label_46->setObjectName(QString::fromUtf8("label_46"));
        label_46->setGeometry(QRect(390, 47, 66, 31));
        label_47 = new QLabel(groundBox);
        label_47->setObjectName(QString::fromUtf8("label_47"));
        label_47->setGeometry(QRect(390, 90, 66, 31));
        rb_Ground_Valid = new QRadioButton(groundBox);
        rb_Ground_Valid->setObjectName(QString::fromUtf8("rb_Ground_Valid"));
        rb_Ground_Valid->setGeometry(QRect(190, 130, 71, 23));
        rb_Ground_Valid->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        rb_Ground_Invalid = new QRadioButton(groundBox);
        rb_Ground_Invalid->setObjectName(QString::fromUtf8("rb_Ground_Invalid"));
        rb_Ground_Invalid->setGeometry(QRect(310, 130, 71, 23));
        rb_Ground_Invalid->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        label_48 = new QLabel(groundBox);
        label_48->setObjectName(QString::fromUtf8("label_48"));
        label_48->setGeometry(QRect(190, 0, 121, 21));
        pushButton = new QPushButton(LOG);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(250, 440, 84, 28));
        pushButton->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);"));
        pushButton_2 = new QPushButton(LOG);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(350, 440, 84, 28));
        pushButton_2->setStyleSheet(QString::fromUtf8("background-color: rgb(239, 41, 41);"));

        retranslateUi(LOG);

        QMetaObject::connectSlotsByName(LOG);
    } // setupUi

    void retranslateUi(QFrame *LOG)
    {
        LOG->setWindowTitle(QApplication::translate("LOG", "Frame", nullptr));
        LOG_cancel->setText(QApplication::translate("LOG", "Cancel", nullptr));
        waterBox->setTitle(QApplication::translate("LOG", "WATER SPEED:", nullptr));
        label_3->setText(QApplication::translate("LOG", "<html><head/><body><p><span style=\" color:#8ae234;\">Longitudinal</span></p></body></html>", nullptr));
        label_4->setText(QApplication::translate("LOG", "<html><head/><body><p><span style=\" color:#8ae234;\">Transverse</span></p></body></html>", nullptr));
        label_5->setText(QApplication::translate("LOG", "<html><head/><body><p><span style=\" color:#8ae234;\">Status</span></p></body></html>", nullptr));
        label_6->setText(QApplication::translate("LOG", "<html><head/><body><p><span style=\" color:#8ae234;\">Kn(0-99)</span></p></body></html>", nullptr));
        label_7->setText(QApplication::translate("LOG", "<html><head/><body><p><span style=\" color:#8ae234;\">Kn(0-99)</span></p></body></html>", nullptr));
        rb_Water_Valid->setText(QApplication::translate("LOG", "Valid", nullptr));
        rb_Water_Invalid->setText(QApplication::translate("LOG", "Invalid", nullptr));
        label_49->setText(QApplication::translate("LOG", "<html><head/><body><p><span style=\" color:#8ae234;\">WATER SPEED</span></p></body></html>", nullptr));
        LOG_confirmn->setText(QApplication::translate("LOG", "Confirm", nullptr));
        groundBox->setTitle(QApplication::translate("LOG", "GROUND SPEED:", nullptr));
        label_43->setText(QApplication::translate("LOG", "<html><head/><body><p><span style=\" color:#8ae234;\">Longitudinal</span></p></body></html>", nullptr));
        label_44->setText(QApplication::translate("LOG", "<html><head/><body><p><span style=\" color:#8ae234;\">Transverse</span></p></body></html>", nullptr));
        label_45->setText(QApplication::translate("LOG", "<html><head/><body><p><span style=\" color:#8ae234;\">Status</span></p></body></html>", nullptr));
        label_46->setText(QApplication::translate("LOG", "<html><head/><body><p><span style=\" color:#8ae234;\">Kn(0-99)</span></p></body></html>", nullptr));
        label_47->setText(QApplication::translate("LOG", "<html><head/><body><p><span style=\" color:#8ae234;\">Kn(0-99)</span></p></body></html>", nullptr));
        rb_Ground_Valid->setText(QApplication::translate("LOG", "Valid", nullptr));
        rb_Ground_Invalid->setText(QApplication::translate("LOG", "Invalid", nullptr));
        label_48->setText(QApplication::translate("LOG", "<html><head/><body><p><span style=\" color:#8ae234;\">GROUND SPEED</span></p></body></html>", nullptr));
        pushButton->setText(QApplication::translate("LOG", "ON", nullptr));
        pushButton_2->setText(QApplication::translate("LOG", "OFF", nullptr));
    } // retranslateUi

};

namespace Ui {
    class LOG: public Ui_LOG {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LOG_H
