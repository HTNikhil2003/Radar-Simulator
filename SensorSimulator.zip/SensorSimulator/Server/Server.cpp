#include "Server.h"
#include "ui_Server.h"

Server::Server(QWidget *parent) :
    QFrame(parent),
    ui(new Ui::Server)
{
    ui->setupUi(this);
    ui->TabWid1->setTabsClosable(true);

    objSendSocket = new QUdpSocket;
    objSendSocket->bind(QHostAddress::LocalHost,1234);
    connect(objSendSocket, SIGNAL(readyRead()), this, SLOT(m_readyRead()));
}

Server::~Server()
{
    delete ui;
}

void Server::m_readyRead()
{
    QByteArray Buffer;
    Buffer.resize(static_cast<int>(objSendSocket->pendingDatagramSize()));

    QHostAddress sender;
    quint16 senderPort;
    objSendSocket->readDatagram(Buffer.data(),Buffer.size(),&sender,&senderPort);

    QString msg = QString::fromUtf8(Buffer);
    ui->TabWid1->setCurrentIndex(1);
    ui->textEdit_2->append(msg);
}

void Server::on_pushButton_clicked()
{
    QByteArray Data;
    Data.append(ui->textEdit->toPlainText());
    objSendSocket->writeDatagram(Data,QHostAddress::LocalHost,1234);
}
