#ifndef TCPSERVER_H
#define TCPSERVER_H

#include <QObject>
#include <QTcpServer>
#include <QTcpSocket>
#include <QDebug>


class TCPServer : public QObject
{
    Q_OBJECT
public:
    explicit TCPServer(QObject *parent = nullptr);

signals:

private:
    QTcpServer *server;

public slots:
    void newConnection();

public:
    TCPServer();
};

#endif // TCPSERVER_H
