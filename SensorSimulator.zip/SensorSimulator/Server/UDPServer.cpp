#include "UDPServer.h"
#include "ui_UDPServer.h"
#include "Server/UDPServer.h"
#include <QUdpSocket>

UDPServer::UDPServer(QWidget *parent) :
    QFrame(parent),
    ui(new Ui::UDPServer)
{
    ui->setupUi(this);

    objSendSocket = new QUdpSocket(this);
    objSendSocket->bind(QHostAddress::Any, 5000);
   // connect(objSendSocket,SIGNAL(on_pushButton_clicked),this,SLOT(on_pushButton_clicked()));
}

UDPServer::~UDPServer()
{
    delete ui;
}


void UDPServer::on_pushButton_clicked()
{

    ui->SenderText->toPlainText();
    objSendSocket = new QUdpSocket;
    objSendSocket->bind(QHostAddress::LocalHost,5000);
    connect(objSendSocket, SIGNAL(readyRead()), this, SLOT(m_readyRead()));

    QByteArray Data;
    ui->ReceiverText->toPlainText();
    objSendSocket->writeDatagram(Data,QHostAddress::LocalHost,1234);

}


