#include "tcpserver.h"
#include <QObject>   // IMPORTANT

TCPServer::TCPServer(QObject *parent)
    : QObject(parent)
{
}
