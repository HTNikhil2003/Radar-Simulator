#ifndef UDPSERVER_H
#define UDPSERVER_H

#include <QFrame>
#include <QUdpSocket>

namespace Ui {
class UDPServer;
}

class UDPServer : public QFrame
{
    Q_OBJECT

public:
    explicit UDPServer(QWidget *parent = nullptr);
    ~UDPServer();

public slots:
//    void m_readyRead();
//    void readPendindDatagrams();

private slots:
    void on_pushButton_clicked();

public slots:
//    void sendData(QString sentence);

private:
    Ui::UDPServer *ui;
    QUdpSocket *objSendSocket;
};

#endif // UDPSERVER_H
