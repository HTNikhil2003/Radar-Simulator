#ifndef SERVER_H
#define SERVER_H

#include <QFrame>
#include <QUdpSocket>

namespace Ui {
class Server;
}

class Server : public QFrame
{
    Q_OBJECT

public:
    explicit Server(QWidget *parent = nullptr);
    ~Server();

public slots:
    void m_readyRead();
//    void readPendindDatagrams();

private slots:
    void on_pushButton_clicked();

private:
    Ui::Server *ui;
    QUdpSocket *objSendSocket;
};

#endif // SERVER_H
